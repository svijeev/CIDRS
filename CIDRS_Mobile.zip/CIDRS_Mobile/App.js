/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * Generated with the UI Kitten myapp
 * https://github.com/akveo/react-native-ui-kitten
 *
 * Documentation: https://akveo.github.io/react-native-ui-kitten/docs
 *
 * @format
 */

import React from 'react';
import {Provider} from 'react-redux';
import {PersistGate} from 'redux-persist/integration/react';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import {ApplicationProvider, IconRegistry} from '@ui-kitten/components';
import {EvaIconsPack} from '@ui-kitten/eva-icons';
import * as eva from '@eva-design/eva';
import {NavigationContainer} from '@react-navigation/native';

import {default as mapping} from './mapping.json';
import {ThemeContext} from './src/contexts/themeContext';
import {IoniconsPack} from './ionicons';

import Navigator from './src/navigation';
import SplashScreen from './src/screens/splash';

import {useStore} from './src/store';

// To see all the requests in the chrome Dev tools in the network tab.
XMLHttpRequest = GLOBAL.originalXMLHttpRequest
  ? GLOBAL.originalXMLHttpRequest
  : GLOBAL.XMLHttpRequest;
// fetch logger
global._fetch = fetch;
global.fetch = function (uri, options, ...args) {
  // global.FormData = global.originalFormData;
  return global._fetch(uri, options, ...args).then(response => {
    return response;
  });
};

export default () => {
  const {store, persist} = useStore();
  const [theme, setTheme] = React.useState('light');

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
  };

  return (
    <SafeAreaProvider>
      <IconRegistry icons={[EvaIconsPack, IoniconsPack]} />
      <ThemeContext.Provider
        value={{theme: theme, toggleTheme: () => toggleTheme()}}>
        <ApplicationProvider
          {...eva}
          theme={eva[theme]}
          customMapping={mapping}>
          {store && persist ? (
            <Provider store={store}>
              <PersistGate loading={<SplashScreen />} persistor={persist}>
                <NavigationContainer>
                  <Navigator />
                </NavigationContainer>
              </PersistGate>
            </Provider>
          ) : (
            <SplashScreen />
          )}
        </ApplicationProvider>
      </ThemeContext.Provider>
    </SafeAreaProvider>
  );
};
