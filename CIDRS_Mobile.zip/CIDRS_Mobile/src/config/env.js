import Config from 'react-native-config';

const envirement = {
  appUrl: Config.APP_URL,
  authUrl: 'http://vijeevcidrs-001-site1.htempurl.com/api/v1/Identity/logIn',
  baseUrl: 'http://vijeevcidrs-001-site1.htempurl.com/api/v1',
  url: 'http://vijeevcidrs-001-site1.htempurl.com',
  isProduction: __DEV__,

  dateFormat: 'YYYY-MM-DD',
  timeFormat: 'HH:mm:ss',
  dateTimeFormat: 'YYYY-MM-DD HH:mm:ss',
};

export default envirement;




