import axios from '../../config/axios';
import * as actionType from './actionType';

export const getAllWorkintems = () => async (dispatch, getState) => {
  try {
    dispatch({type: actionType.GET_ALL_WORKITEMS_REQUEST});
    const {data} = await axios.get(
      `WorkItems?isActive=true&type=1&page=1&pageSize=100`,
    );
    dispatch({
      type: actionType.GET_ALL_WORKITEMS_SUCCESS,
      payload: data,
    });

    return data;
  } catch (error) {
    dispatch({
      type: actionType.GET_ALL_WORKITEMS_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const getWorkintem = id => async (dispatch, getState) => {
  try {
    dispatch({type: actionType.GET_WORKITEM_REQUEST});
    const {data} = await axios.get(`WorkItems/${id}`);
    dispatch({
      type: actionType.GET_WORKITEM_SUCCESS,
      payload: data?.result,
    });

    return data;
  } catch (error) {
    dispatch({
      type: actionType.GET_WORKITEM_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const getStartReporting = values => async (dispatch, getState) => {
  try {
    dispatch({type: actionType.GET_START_REPORTING_REQUEST});
    const {data} = await axios.post(
      `ReportingApplication/start?chiefOccupantId=${values.chiefOccupantId}`,
    );
    dispatch({
      type: actionType.GET_START_REPORTING_SUCCESS,
      payload: data?.result,
    });

    return data;
  } catch (error) {
    dispatch({
      type: actionType.GET_START_REPORTING_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const passWorkItemId = value => async (dispatch, getState) => {
  try {
    dispatch({type: actionType.GET_PASS_WORKITEM_ID_REQUEST});
    dispatch({
      type: actionType.GET_PASS_WORKITEM_ID_SUCCESS,
      payload: value,
    });
  } catch (error) {
    dispatch({
      type: actionType.GET_PASS_WORKITEM_ID_FAIL,
    });
  }
};

export const getCOStartReporting = values => async (dispatch, getState) => {
  try {
    dispatch({type: actionType.GET_START_REPORTING_REQUEST});
    const {data} = await axios.post(`ReportingApplication/start?isPublicSurroundingApplication=false`);
    dispatch({
      type: actionType.GET_START_REPORTING_SUCCESS,
      payload: data?.result,
    });

    return data;
  } catch (error) {
    dispatch({
      type: actionType.GET_START_REPORTING_FAIL,
      payload: error.response && error.response.data,
    });
  }
};