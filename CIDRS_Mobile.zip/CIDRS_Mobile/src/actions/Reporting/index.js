import axios from '../../config/axios';
import {
  GET_REPORTING_FAIL,
  GET_REPORTING_REQUEST,
  GET_REPORTING_SUCCESS,
  GET_REPORTING_CREATE_FAIL,
  GET_REPORTING_CREATE_REQUEST,
  GET_REPORTING_CREATE_SUCCESS,
  GET_PASS_REPORTING_ID_FAIL,
  GET_PASS_REPORTING_ID_REQUEST,
  GET_PASS_REPORTING_ID_SUCCESS,
  SET_CHIEF_OCCUPANT_ID_REQUEST,
  SET_CHIEF_OCCUPANT_ID_SUCCESS,
  SET_CHIEF_OCCUPANT_ID_FAIL,
  SET_SURRONDING_SET_REQUEST,
  SET_SURRONDING_SET_SUCCESS,
  SET_SURRONDING_SET_FAIL,
  COMPLETE_SURRONDING_SET_FAIL,
  COMPLETE_SURRONDING_SET_SUCCESS,
  COMPLETE_SURRONDING_SET_REQUEST
} from './actionType';

export const getReporting = id => async (dispatch, getState) => {
  try {
    dispatch({type: GET_REPORTING_REQUEST});
    const {data} = await axios.get(`ReportingApplication/${id}`);
    dispatch({
      type: GET_REPORTING_SUCCESS,
      payload: data.result,
    });
    return data;
  } catch (error) {
    dispatch({
      type: GET_REPORTING_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const reportingCreate = values => async (dispatch, getState) => {
  try {
    dispatch({type: GET_REPORTING_CREATE_REQUEST});
    const {data} = await axios.post(
      `ReportingApplication/base-surrounding-set?chiefOccupantId=${values?.chiefOccupantId}`,
      values,
    );
    dispatch({
      type: GET_REPORTING_CREATE_SUCCESS,
      payload: data,
    });
    return data;
  } catch (error) {
    dispatch({
      type: GET_REPORTING_CREATE_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const passReportingId = value => async (dispatch, getState) => {
  try {
    dispatch({type: GET_PASS_REPORTING_ID_REQUEST});
    dispatch({
      type: GET_PASS_REPORTING_ID_SUCCESS,
      payload: value,
    });
  } catch (error) {
    dispatch({
      type: GET_PASS_REPORTING_ID_FAIL,
    });
  }
};

export const setChiefOccupantId = value => async (dispatch, getState) => {
  try {
    dispatch({type: SET_CHIEF_OCCUPANT_ID_REQUEST});
    dispatch({
      type: SET_CHIEF_OCCUPANT_ID_SUCCESS,
      payload: value,
    });
  } catch (error) {
    dispatch({
      type: SET_CHIEF_OCCUPANT_ID_FAIL,
    });
  }
};
export const setSurroundingSet = values => async (dispatch, getState) => {
  try {
    dispatch({type: SET_SURRONDING_SET_REQUEST});
    dispatch({
      type: SET_SURRONDING_SET_SUCCESS,
      payload: values,
    });
  } catch (error) {
    dispatch({
      type: SET_SURRONDING_SET_FAIL,
    });
  }
};

export const addSurroundingSet = values => async (dispatch, getState) => {
  try {
    const {data} = await axios.put(
      `ReportingApplication/surrounding-set`,
      values,
    );

    return data;
  } catch (error) {}
};


export const completeSurroundingSet = chiefOccupantId => async (dispatch, getState) => {
  try {
    dispatch({type: COMPLETE_SURRONDING_SET_REQUEST});
    const {data} = await axios.post(
      `ReportingApplication/complete?chiefOccupantId=${chiefOccupantId}&isPublicSurroundingApplication=false` );
    dispatch({
        type: COMPLETE_SURRONDING_SET_SUCCESS,
        payload: data,
      });
    return data;
  } catch (error) {
    dispatch({
      type: COMPLETE_SURRONDING_SET_FAIL,
    });
  }
};

export const CoCompleteSurroundingSet = () => async (dispatch, getState) => {
  try {
    dispatch({type: COMPLETE_SURRONDING_SET_REQUEST});
    const {data} = await axios.post(
      `ReportingApplication/complete?isPublicSurroundingApplication=false` );
    dispatch({
        type: COMPLETE_SURRONDING_SET_SUCCESS,
        payload: data,
      });
    return data;
  } catch (error) {
    dispatch({
      type: COMPLETE_SURRONDING_SET_FAIL,
    });
  }
};
