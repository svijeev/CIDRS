import * as actionTypes from './actionType';
import axios from '../../config/axios';

export const getDistricts = () => async (dispatch, getState) => {
  try {
    dispatch({type: actionTypes.GET_DISTRACT_REQUEST});
    const {data} = await axios.get(`/MasterData/districts`);
    dispatch({
      type: actionTypes.GET_DISTRACT_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: actionTypes.GET_DISTRACT_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const getMohAreas = () => async (dispatch, getState) => {
  try {
    dispatch({type: actionTypes.GET_MOH_AREA_REQUEST});
    const {data} = await axios.get(`MasterData/moh-areas`);
    dispatch({
      type: actionTypes.GET_MOH_AREA_SUCCESS,
      payload: data ,
    });
  } catch (error) {
    dispatch({
      type: actionTypes.GET_DISTRACT_SUCCESS,
      payload: error.response && error.response.data,
    });
  }
};
