import axios from '../../config/axios';
import env from '../../config/env';
import {
  LOGIN_SUCCESS,
  PURGE,
  GET_REGISTER_FAIL,
  GET_REGISTER_SUCCESS,
  GET_REGISTER_REQUEST,
  GET_PHONE_VERIFY_FAIL,
  GET_PHONE_VERIFY_REQUEST,
  GET_PHONE_VERIFY_SUCCESS,
  GET_PHONE_VERIFY_CODR_RESEND_FAIL,
  GET_PHONE_VERIFY_CODR_RESEND_SUCCESS,
  GET_PHONE_VERIFY_CODR_RESEND_REQUEST,
  GET_CURRENT_USER_FAIL,
  GET_CURRENT_USER_REQUEST,
  GET_CURRENT_USER_SUCCESS,
  GET_EMAIL_VERIFY_CODR_RESEND_FAIL,
  GET_EMAIL_VERIFY_CODR_RESEND_REQUEST,
  GET_EMAIL_VERIFY_CODR_RESEND_SUCCESS,
  GET_EMAIL_VERIFY_REQUEST,
  GET_EMAIL_VERIFY_FAIL,
  GET_EMAIL_VERIFY_SUCCESS,
} from './actionType';

export const login = values => {
  return async dispatch => {
    const value = await axios.post(env.authUrl, {
      ...values,
    });
    const loginSuccessAction = {
      type: LOGIN_SUCCESS,
      response: value.data,
    };
    dispatch(loginSuccessAction);
    return value.data;
  };
};

export const currentUser = () => async (dispatch, getState) => {
  try {
    dispatch({type: GET_CURRENT_USER_REQUEST});
    const {data} = await axios.get(`Identity/current-user`);
    dispatch({
      type: GET_CURRENT_USER_SUCCESS,
      payload: data,
    });
    return data;
  } catch (error) {
    dispatch({
      type: GET_CURRENT_USER_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const logout = () => {
  const logoutAction = {
    type: PURGE,
    result: () => null,
  };

  return logoutAction;
};

export const register = values => async (dispatch, getState) => {
  try {
    dispatch({type: GET_REGISTER_REQUEST});
    const {data} = await axios.post(`ChiefOccupant/register-co`, values);
    dispatch({
      type: GET_REGISTER_SUCCESS,
      payload: data,
    });
    return data;
  } catch (error) {
    dispatch({
      type: GET_REGISTER_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const phoneVerify = values => async (dispatch, getState) => {
  try {
    dispatch({type: GET_PHONE_VERIFY_REQUEST});
    const {data} = await axios.post(`Identity/conform-mobile`, values);
    dispatch({
      type: GET_PHONE_VERIFY_SUCCESS,
      payload: data,
    });

    return data;
  } catch (error) {
    dispatch({
      type: GET_PHONE_VERIFY_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const phoneNumberResend = () => async (dispatch, getState) => {
  try {
    dispatch({type: GET_PHONE_VERIFY_CODR_RESEND_REQUEST});
    const {data} = await axios.post(
      `Identity/request-mobile-verification-code`,
    );
    dispatch({
      type: GET_PHONE_VERIFY_CODR_RESEND_SUCCESS,
      payload: data,
    });
    return data;
  } catch (error) {
    dispatch({
      type: GET_PHONE_VERIFY_CODR_RESEND_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const emailTokenResend = () => async (dispatch, getState) => {
  try {
    dispatch({type: GET_EMAIL_VERIFY_CODR_RESEND_REQUEST});
    const {data} = await axios.post(`Identity/request-email-verification-code`);

    dispatch({
      type: GET_EMAIL_VERIFY_CODR_RESEND_SUCCESS,
      payload: data,
    });
    return data;
  } catch (error) {
    dispatch({
      type: GET_EMAIL_VERIFY_CODR_RESEND_FAIL,
      payload: error.response && error.response.data,
    });
  }
};

export const emailVerify = values => async (dispatch, getState) => {
  try {
    dispatch({type: GET_EMAIL_VERIFY_REQUEST});
    const {data} = await axios.post(`Identity/conform-email`, values);
    dispatch({
      type: GET_EMAIL_VERIFY_SUCCESS,
      payload: data,
    });

    return data;
  } catch (error) {
    dispatch({
      type: GET_EMAIL_VERIFY_FAIL,
      payload: error.response && error.response.data,
    });
  }
};
