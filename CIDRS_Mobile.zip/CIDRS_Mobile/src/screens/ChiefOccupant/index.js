import React from 'react';
import {SafeAreaView} from 'react-native';
import {Button, Layout} from '@ui-kitten/components';

import Header from '../../components/shared/Header';

const ChiefOccupantScreen = ({navigation}) => {
  return (
    <SafeAreaView style={{flex: 1}}>
      <Header navigation={navigation} title="Chief Occupant" isBack={false} />
      <Layout style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <Button>OPEN DETAILS</Button>
      </Layout>
    </SafeAreaView>
  );
};
export default ChiefOccupantScreen;
