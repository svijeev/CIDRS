import React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {SafeAreaView, ActivityIndicator} from 'react-native';
import {List, ListItem, Divider, Icon, Button} from '@ui-kitten/components';
import {getAllWorkintems, passWorkItemId} from '../../actions/workItems';
import {setChiefOccupantId} from '../../actions/Reporting';
import colors from '../../constants/colors';
import Ionicons from 'react-native-vector-icons/Ionicons';

import Header from '../../components/shared/Header';
import moment from 'moment-timezone';

const PhiScreen = ({navigation}) => {
  const dispatch = useDispatch();
  React.useEffect(() => {
    dispatch(getAllWorkintems());
  }, [dispatch]);

  const onSelectItem = async item => {
    await dispatch(passWorkItemId(item?.id));
    await dispatch(setChiefOccupantId(item?.id));
    navigation.navigate('WorkItem Details');
  };

  const {workItems, loading} = useSelector(state => state.workItems);

  const renderItem = ({item, index}) => (
    <ListItem
      title={`${item?.identifier}- ${moment(item?.identifier?.createdAt).format(
        'LL',
      )}`}
      description={`${item?.chiefOccupant?.fullName}- ${item?.chiefOccupant?.phoneNumber}`}
      accessoryRight={() => (
        <Ionicons name="ellipsis-vertical-outline" size={23} />
      )}
      onPress={() => onSelectItem(item)}
    />
  );
  if (loading) {
    return <ActivityIndicator size="large" color={colors.primary} />;
  }
  return (
    <SafeAreaView style={{flex: 1}}>
      <Header navigation={navigation} title="Work Items" isBack={false} />
      <List
        data={workItems?.results}
        ItemSeparatorComponent={Divider}
        renderItem={renderItem}
      />
    </SafeAreaView>
  );
};
export default PhiScreen;
