import React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {SafeAreaView, View, ActivityIndicator, ScrollView} from 'react-native';
import {Button, Text, Card} from '@ui-kitten/components';
import {getWorkintem, getStartReporting} from '../../../actions/workItems';
import {passReportingId} from '../../../actions/Reporting';
import Header from '../../../components/shared/Header';
import colors from '../../../constants/colors';

const Index = ({route, navigation}) => {
  // const {id} = route.params;
  const dispatch = useDispatch();
  const {workItem, workItemId, loading} = useSelector(state => state.workItems);

  React.useEffect(() => {
    dispatch(getWorkintem(workItemId));
  }, [dispatch]);

  const onStartReporting = async () => {
    const res = await dispatch(
      await getStartReporting({
        chiefOccupantId: workItem?.chiefOccupant?.id,
        isPublicSurroundingApplication: false
      })
    );
    await navigation.navigate('Reporting');

    await dispatch(passReportingId(res?.result?.id));
  };

  const ViewItem = ({name, value}) => {
    return (
      <Card>
        <View style={{flexDirection: 'row'}}>
          <Text>{name} -</Text>
          <Text appearance="hint"> {value}</Text>
        </View>
      </Card>
    );
  };

  if (loading) {
    return <ActivityIndicator size="large" color={colors.primary} />;
  }
  return (
    <SafeAreaView style={{flex: 1}}>
      <Header
        navigation={navigation}
        title={workItem?.identifier}
        isBack={true}
      />
      <ScrollView>
        <View
          style={{
            backgroundColor: 'white',
            height: '100%',
          }}>
          <Text style={{margin: 10, fontWeight: 'bold'}}>
            CHIFE OCCUPANT DETAILS
          </Text>
          <ViewItem
            name="Full Name"
            value={workItem?.chiefOccupant?.fullName}
          />
          <ViewItem
            name="Phone Number"
            value={workItem?.chiefOccupant?.phoneNumber}
          />
          <ViewItem
            name="District"
            value={workItem?.chiefOccupant?.district?.name}
          />
          <ViewItem
            name="MOH Area"
            value={workItem?.chiefOccupant?.mohArea?.name}
          />
          <ViewItem name="Address" value={workItem?.chiefOccupant?.address} />

          <Text style={{margin: 10, fontWeight: 'bold'}}>PHI DETAILS</Text>
          <ViewItem
            name="Full Name"
            value={workItem?.chiefOccupant?.respectivePhi?.fullName}
          />
          <ViewItem
            name="Phone Number"
            value={workItem?.chiefOccupant?.respectivePhi?.phoneNumber}
          />

          <Text style={{margin: 10, fontWeight: 'bold'}}>POLICE DETAILS</Text>
          <ViewItem
            name="Full Name"
            value={workItem?.chiefOccupant?.respectivePolice?.fullName}
          />
          <ViewItem
            name="Phone Number"
            value={workItem?.chiefOccupant?.respectivePolice?.mobile}
          />
          {/* <ViewItem
            name="Station"
            value={workItem?.respectivePolice?.policeStation?.name}
          /> */}

          <Button
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              margin: 20,
            }}
            size="medium"
            status="success"
            onPress={() => onStartReporting()}>
            Start Reporting
          </Button>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
export default Index;
