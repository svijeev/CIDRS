import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { SafeAreaView, View, ScrollView, ActivityIndicator } from 'react-native';
import { Text, Button } from '@ui-kitten/components';
import Header from '../../../components/shared/Header';
import { Card, Icon } from 'react-native-elements';
import { getReporting, completeSurroundingSet } from '../../../actions/Reporting';
import {getAllWorkintems} from '../../../actions/workItems';
import colors from '../../../constants/colors';
import { url as apiUrl } from '../../../config/env';

const Index = ({ route, navigation }) => {
  const dispatch = useDispatch();
  const { reportId, chiefOccupantId } = useSelector(state => state.reporting);

  React.useEffect(() => {
    reportId && dispatch(getReporting(reportId));
  }, [dispatch, reportId, chiefOccupantId, navigation]);

  const { reports, loading } = useSelector(state => state.reporting);

  const completeSurrounding = async() => {
   const {succeeded} = await dispatch(completeSurroundingSet(chiefOccupantId));
   if(succeeded){
    await dispatch(getAllWorkintems());
    await navigation.navigate('PHI');
    }
  }

  if (loading) {
    return <ActivityIndicator size="large" color={colors.primary} />;
  }
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Header navigation={navigation} title="Reporting" isBack={true} />
      <View
        style={{
          flex: 1,
          flexDirection: 'column',
          justifyContent: 'space-between',
        }}>
        <ScrollView>
          {reports?.surroundingSets?.map(item => {
            return (
              <Card key={item?.id}>
                <Card.Title>{item?.name}</Card.Title>
                <Card.Image
                  source={
                    item?.imageUrl
                      ? {
                        uri: `http://vijeevcidrs-001-site1.htempurl.com/${item.imageUrl}`,
                      }
                      : require('../../../assets/img/logo.png')
                  }
                />
                <Text appearance="hint" style={{ marginBottom: 10 }}>
                  {item?.description}
                </Text>
              </Card>
            );
          })}
        </ScrollView>
        <View>
          <Button
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              margin: 20,
            }}
            size="medium"
            status="success"
            onPress={() => navigation.navigate('Reporting Create')}>
            Add New
          </Button>
        </View>
        {reports?.surroundingSets?.length != 0 && (
          <Button
            style={{ alignItems: 'center', justifyContent: 'center', margin: 20 }}
            appearance="outline"
            onPress={() => completeSurrounding()}
            >
            COMPLETE
          </Button>
        )}
      </View>
    </SafeAreaView>
  );
};
export default Index;
