import React, {useState, useEffect, useCallback} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {SafeAreaView, ActivityIndicator} from 'react-native';
// import {Text, Card} from '@ui-kitten/components';
import Geolocation from '@react-native-community/geolocation';
import Header from '../../../../components/shared/Header';

import colors from '../../../../constants/colors';
import {reportingCreate, getReporting} from '../../../../actions/Reporting';
import Form from './Form';
import {toString} from 'lodash';

const Index = ({route, navigation}) => {
  const dispatch = useDispatch();

  const [location, setLocation] = useState({});

  useEffect(() => {
    Geolocation.getCurrentPosition(info => {
      setLocation({
        latitude: toString(info?.coords?.latitude),
        longitude: toString(info?.coords?.longitude),
      });
    });
  }, []);

  const onSubmit = useCallback(async (values, formikHelpers) => {
    formikHelpers.setSubmitting(true);

    try {
      const res = await dispatch(
        reportingCreate({
          image: values?.image,
          name: values?.name,
          description: values?.description,
          latitude: location?.latitude,
          longitude: location?.longitude,
          chiefOccupantId: chiefOccupantId,
        }),
      );
      if (res?.succeeded) {
        reportId && dispatch(getReporting(reportId));
        await navigation.navigate('Reporting');
      }
      if (res.errors) {
        formikHelpers.setSubmitting(false);
        if (error?.response?.status === 400) {
          formikHelpers.setFieldError('name', res.errors[0]);
        }
      }
    } catch (error) {
      formikHelpers.setSubmitting(false);
      if (error?.response?.status === 400) {
        formikHelpers.setFieldError('name', 'Name already exits.');
      }
    }
  }, []);
  const {loading, chiefOccupantId, reportId} = useSelector(state => state.reporting);
  

  if (loading) {
    return <ActivityIndicator size="large" color={colors.primary} />;
  }

  return (
    <SafeAreaView style={{flex: 1}}>
      <Header navigation={navigation} title="Reporting Create" isBack={true} />
      <Form onSubmit={onSubmit} navigation={navigation} />
    </SafeAreaView>
  );
};
export default Index;
