import React, {useState} from 'react';
import {Formik} from 'formik';
import {object, string} from 'yup';
import {View, Image, TouchableOpacity} from 'react-native';
import {Button, Card, Text} from '@ui-kitten/components';
// import DocumentPicker from 'react-native-document-picker';
import CoreImagePicker from 'react-native-image-picker';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {FormLayout, Input} from '../../../../components/base/FormControls';
import styles from './styles';

const options = {
  title: 'surroundingSets',
  mediaType: 'photo',
  storageOptions: {
    skipBackup: true,
    path: 'CIDRS',
    waitUntilSaved: true,
  },
};

const LoginScreen = ({onSubmit, navigation}) => {
  const initialValues = {
    name: '',
    description: '',
    image: '',
  };
  const validationSchema = object().shape({
    description: string().required('Description is required.'),
    name: string().required('Name is required.'),
    image: object().nullable(),
  });

  return (
    <Formik
      validationSchema={validationSchema}
      initialValues={initialValues}
      onSubmit={onSubmit}>
      {({
        handleChange,
        handleBlur,
        handleSubmit,
        values,
        touched,
        errors,
        isValid,
        isSubmitting,
        setValues,
      }) => {
        // const selectOneFile = async () => {
        //   const res = await DocumentPicker.pick({
        //     type: [DocumentPicker.types.images],
        //   });

        //   setValues({...values, image: res[0]});
        // };

        const openComera = () => {
          CoreImagePicker.launchImageLibrary(options, response => {
            onResponse(response);
          });
        };

        const onResponse = response => {
          if (
            !response.didCancel &&
            !response.error &&
            !response.customButton
          ) {
            const file = `data:image/png;base64,${response.data}`;
            setValues({...values, image: file});
          }
        };

        const invalidName = touched.name && errors.name;
        const invalidDescription = touched.description && errors.description;
        const invalidImage = touched.image && errors.image;

        return (
          <View style={{height: '100%', backgroundColor: '#FFFFFF'}}>
            <FormLayout style={styles.formContainer}>
              <Input
                placeholder="Name"
                label="Name"
                returnKeyType="next"
                value={values.name}
                disabled={isSubmitting}
                onBlur={handleBlur('name')}
                onChangeText={handleChange('name')}
                status={invalidName ? 'danger' : 'basic'}
                caption={invalidName ? errors.name : undefined}
              />
              <Input
                style={styles.formInput}
                label="description"
                placeholder="description"
                value={values.description}
                disabled={isSubmitting}
                onBlur={handleBlur('description')}
                onChangeText={handleChange('description')}
                status={invalidDescription ? 'danger' : 'basic'}
                caption={invalidDescription ? errors.description : undefined}
                onSubmitEditing={handleSubmit}
              />
              {values.image ? (
                <TouchableOpacity
                  onPress={() => openComera()}
                  style={{
                    marginTop: 20,
                    borderRadius: 20,
                    borderStyle: 'dashed',
                    borderColor: '#EEEEEE',
                    borderWidth: 3,
                    width: '100%',
                    height: '40%',
                  }}>
                  <Image
                    style={{width: '100%', height: '100%', borderRadius: 20}}
                    source={{
                      uri: values.image,
                    }}
                  />
                </TouchableOpacity>
              ) : (
                <Card
                  // onPress={() => selectOneFile()}
                  onPress={() => openComera()}
                  style={{
                    marginTop: 20,
                    borderRadius: 20,
                    borderStyle: 'dashed',
                    borderWidth: 3,
                    width: '100%',
                    height: '30%',
                  }}>
                  <View style={{alignItems: 'center', flexDirection: 'column'}}>
                    <Ionicons size={50} name="cloud-upload-outline" />
                    <Text>{invalidImage}</Text>
                  </View>
                </Card>
              )}

              <Button
                disabled={!isValid || isSubmitting}
                style={styles.signInButton}
                onPress={handleSubmit}
                size="giant">
                {isSubmitting ? 'SUBMITTING...' : 'SUBMIT'}
              </Button>
            </FormLayout>
          </View>
        );
      }}
    </Formik>
  );
};

export default LoginScreen;
