import React from 'react';
import {SafeAreaView} from 'react-native';
import {Button, Layout} from '@ui-kitten/components';

import Header from '../../../components/shared/Header';

const HomeScreen = ({navigation}) => {
  return (
    <SafeAreaView style={{flex: 1}}>
      <Header navigation={navigation} title="Home" isBack={false} />
      <Layout
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}></Layout>
    </SafeAreaView>
  );
};
export default HomeScreen;
