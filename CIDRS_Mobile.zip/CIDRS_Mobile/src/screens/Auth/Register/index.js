import React, { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import * as Animatable from 'react-native-animatable';
import {
  Layout,
  TopNavigation,
  Divider,
  Icon,
  TopNavigationAction,
} from '@ui-kitten/components';
import KeyboardAvoidingView from '../../../components/base/KeyboardAvoidingView';
import Form from './Form';
import styles from './styles';
import { View } from 'react-native';
import { register, login } from '../../../actions/auth';

const BackIcon = props => <Icon {...props} name="arrow-back" />;

const LoginScreen = ({ navigation }) => {
  const dispatch = useDispatch();
  const onSignIn = useCallback(async (values, formikHelpers) => {
    formikHelpers.setSubmitting(true);
    try {
      await dispatch(
        register({
          ...values,
          districtId: values?.district?.id,
          mohAreaId: values?.mohArea?.id,
        }),
      );

      await dispatch(
        login({
          username: values?.phoenNumber,
          password: values?.password,
        }),
      );
    } catch (error) {
      formikHelpers.setSubmitting(false);
      if (error?.response?.status === 400) {
        formikHelpers.setFieldError(
          'username',
          'These credentials do not match our records.',
        );
      }
    }
  }, []);

  return (
    <Layout style={styles.mainContainer}>
      <Animatable.View animation="fadeInRight" duraton="2000">
        <TopNavigation
          title="Sign in"
          accessoryLeft={() => (
            <TopNavigationAction
              icon={BackIcon}
              onPress={() => navigation.navigate('Login')}
            />
          )}
        />
      </Animatable.View>
      <Divider />
      <KeyboardAvoidingView>
        <Animatable.View animation="fadeInUpBig">
          <Form onSubmit={onSignIn} navigation={navigation} />
        </Animatable.View>
      </KeyboardAvoidingView>
    </Layout>
  );
};

export default LoginScreen;
