import {StyleService} from '@ui-kitten/components';

const themedStyles = StyleService.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '40%',
  },
  formContainer: {
    flex: 1,
    paddingTop: 32,
    paddingHorizontal: 16,
  },
  signInButton: {
    marginHorizontal: 16,
    borderRadius: 20,
    marginTop: 20,
  },
  signUpButton: {
    marginVertical: 12,
    marginHorizontal: 16,
  },

  passwordInput: {
    marginTop: 16,
  },

  formInput: {
    marginTop: 16,
  },
});

export default themedStyles;
