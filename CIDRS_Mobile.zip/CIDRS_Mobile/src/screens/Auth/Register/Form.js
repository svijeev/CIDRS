import React, {useState, useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {Formik} from 'formik';
import {object, string} from 'yup';
import {View} from 'react-native';
import {Button} from '@ui-kitten/components';
import SearchDropdown from '../../../components/SearchDropdown';

import {FormLayout, Input} from '../../../components/base/FormControls';
import {getDistricts, getMohAreas} from '../../../actions/masterData';
import {
  districts as useDistricts,
  mohAreas as useMohAreas,
  loading as useLoading,
} from '../../../selectors/masterData';
import styles from './styles';

const movies = [
  {title: 'Star Wars'},
  {title: 'Back to the Future'},
  {title: 'The Matrix'},
  {title: 'Inception'},
  {title: 'Interstellar'},
];

const filter = (item, query) =>
  item.name.toLowerCase().includes(query.toLowerCase());

const initialValues = {
  fullName: '',
  phoenNumber: '',
  email: '',
  password: '',
  district: '',
  mohArea: '',
};

const validationSchema = object().shape({
  fullName: string().required('Full Name is required.'),
  phoenNumber: string().required('Phone Number is required.'),
  email: string().required('E-mail Number is required.').email(),
  password: string().required('Password is required.'),
  address: string().required('Address is required.'),
  district: object().required('District is required.'),
  mohArea: object().required('Moh area is required.'),
});

const RegisterScreen = ({onSubmit, navigation}) => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getDistricts());
    dispatch(getMohAreas());
  }, [dispatch]);

  const districtArray = useSelector(useDistricts);
  const mohAreas = useSelector(useMohAreas);
  const loading = useSelector(useLoading);

  return (
    <Formik
      validationSchema={validationSchema}
      initialValues={initialValues}
      onSubmit={onSubmit}>
      {({
        handleChange,
        handleBlur,
        handleSubmit,
        values,
        touched,
        errors,
        isValid,
        isSubmitting,
        setValues,
      }) => {
        const invalidFullname = touched.fullName && errors.fullName;
        const invalidPhoneNumber = touched.phoenNumber && errors.phoenNumber;
        const invalidEmail = touched.email && errors.email;
        const invalidPassword = touched.password && errors.password;
        const invalidAddress = touched.address && errors.address;
        const invalidDistrict = touched.district && errors.district;
        const invalidMohArea = touched.mohArea && errors.mohArea;
        return (
          <View>
            <FormLayout style={styles.formContainer}>
              <Input
                placeholder="hint: John wick"
                label="Full Name"
                returnKeyType="next"
                value={values.fullName}
                disabled={isSubmitting}
                onBlur={handleBlur('fullName')}
                onChangeText={handleChange('fullName')}
                status={invalidFullname ? 'danger' : 'basic'}
                caption={invalidFullname ? errors.fullName : undefined}
              />
              <Input
                placeholder="hint: 94712345678"
                label="Phone Number"
                returnKeyType="next"
                value={values.phoenNumber}
                disabled={isSubmitting}
                onBlur={handleBlur('phoenNumber')}
                onChangeText={handleChange('phoenNumber')}
                status={invalidPhoneNumber ? 'danger' : 'basic'}
                caption={invalidPhoneNumber ? errors.phoenNumber : undefined}
                keyboardType="phone-pad"
              />
              <Input
                placeholder="hint: email@example.com"
                label="E-mail"
                returnKeyType="next"
                value={values.email}
                disabled={isSubmitting}
                onBlur={handleBlur('email')}
                onChangeText={handleChange('email')}
                status={invalidEmail ? 'danger' : 'basic'}
                caption={invalidEmail ? errors.email : undefined}
                keyboardType="email-address"
              />
              <Input
                style={styles.formInput}
                label="Password"
                placeholder="**********"
                secureTextEntry={true}
                value={values.password}
                disabled={isSubmitting}
                onBlur={handleBlur('password')}
                onChangeText={handleChange('password')}
                status={invalidPassword ? 'danger' : 'basic'}
                caption={invalidPassword ? errors.password : undefined}
                onSubmitEditing={handleSubmit}
              />

              <SearchDropdown
                defaultValue={values.district}
                name={values.district}
                label="District"
                style={styles.formInput}
                listItems={districtArray}
                disabled={isSubmitting}
                onSuccess={item => {
                  setValues({...values, district: item});
                }}
                subPlaceholder={'Search...'}
                placeholder={'choose a district'}
                caption={invalidDistrict ? errors.district : undefined}
              />
              <SearchDropdown
                defaultValue={values.mohArea}
                name={values.mohArea}
                label="Moh Area"
                style={styles.formInput}
                listItems={mohAreas}
                disabled={isSubmitting}
                onSuccess={item => {
                  setValues({...values, mohArea: item});
                }}
                subPlaceholder={'Search...'}
                placeholder={'choose a moh area'}
                caption={invalidMohArea ? errors.mohArea : undefined}
              />

              <Input
                style={styles.formInput}
                label="address"
                placeholder="Jaffna Sri lanaka"
                value={values.address}
                disabled={isSubmitting}
                onBlur={handleBlur('address')}
                onChangeText={handleChange('address')}
                status={invalidAddress ? 'danger' : 'basic'}
                caption={invalidAddress ? errors.address : undefined}
                onSubmitEditing={handleSubmit}
                multiline={true}
                numberOfLines={3}
              />
              <Button
                disabled={!isValid || isSubmitting}
                style={styles.signInButton}
                onPress={handleSubmit}
                size="giant">
                {isSubmitting ? 'Submitting...' : 'Submit'}
              </Button>
            </FormLayout>
          </View>
        );
      }}
    </Formik>
  );
};

export default RegisterScreen;
