import React, {useCallback} from 'react';
import * as Animatable from 'react-native-animatable';
import {useDispatch} from 'react-redux';
import {View} from 'react-native';
import {Text, Layout} from '@ui-kitten/components';
import ImageOverlay from '../../../components/base/ImageOverlay';
import KeyboardAvoidingView from '../../../components/base/KeyboardAvoidingView';
import Form from './Form';
import styles from './styles';
import {login} from '../../../actions/auth';

const LoginScreen = ({navigation}) => {
  const dispatch = useDispatch();

  const onSignIn = useCallback(async (values, formikHelpers) => {
    formikHelpers.setSubmitting(true);
    try {
      await dispatch(login(values));
    } catch (error) {
      formikHelpers.setSubmitting(false);
      if (error?.response?.status === 400) {
        formikHelpers.setFieldError(
          'username',
          'These credentials do not match our records.',
        );
      }
    }
  }, []);

  return (
    <KeyboardAvoidingView>
      <ImageOverlay
        style={styles.container}
        source={require('../../../assets/img/logo.png')}>
        <Animatable.View
          animation="bounceIn"
          duraton="1500"
          style={styles.container}>
          <Text category="h4" status="control">
            Sign in to your account
          </Text>
        </Animatable.View>
      </ImageOverlay>
      <Layout style={styles.mainContainer}>
        <Animatable.View animation="fadeInUpBig">
          <Form onSubmit={onSignIn} navigation={navigation} />
        </Animatable.View>
      </Layout>
    </KeyboardAvoidingView>
  );
};

export default LoginScreen;
