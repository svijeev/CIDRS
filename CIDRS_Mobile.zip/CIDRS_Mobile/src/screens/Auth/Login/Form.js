import React from 'react';
import {Formik} from 'formik';
import {object, string} from 'yup';
import {View} from 'react-native';
import {Button} from '@ui-kitten/components';

import {FormLayout, Input} from '../../../components/base/FormControls';
import styles from './styles';

const phoneRegExp = /(94\d{9}$)|(^[^@\s]+@[^@\s]+\.[^@\s]+$)/;
const initialValues = {
  username: '94706431621',
  password: 'Phi@1234',
};

const validationSchema = object().shape({
  password: string().required('Password is required.'),
  username: string()
    .matches(phoneRegExp, 'E-mai or phone number is not valid')
    .required('E-mail is required.'),
});

const LoginScreen = ({onSubmit, navigation}) => {
  return (
    <Formik
      validationSchema={validationSchema}
      initialValues={initialValues}
      onSubmit={onSubmit}>
      {({
        handleChange,
        handleBlur,
        handleSubmit,
        values,
        touched,
        errors,
        isValid,
        isSubmitting,
      }) => {
        const invalidUsername = touched.username && errors.username;
        const invalidPassword = touched.password && errors.password;
        return (
          <View>
            <FormLayout style={styles.formContainer}>
              <Input
                placeholder="Email/ Phone Number"
                label="Email/Phone number"
                returnKeyType="next"
                value={values.username}
                disabled={isSubmitting}
                onBlur={handleBlur('username')}
                onChangeText={handleChange('username')}
                status={invalidUsername ? 'danger' : 'basic'}
                caption={invalidUsername ? errors.username : undefined}
              />
              <Input
                style={styles.formInput}
                label="Password"
                placeholder="Password"
                //secureTextEntry={true}
                value={values.password}
                disabled={isSubmitting}
                onBlur={handleBlur('password')}
                onChangeText={handleChange('password')}
                status={invalidPassword ? 'danger' : 'basic'}
                caption={invalidPassword ? errors.password : undefined}
                onSubmitEditing={handleSubmit}
              />
              { <View style={styles.forgotPasswordContainer}>
                <Button
                  style={styles.forgotPasswordButton}
                  appearance="ghost"
                  status="basic"
                  onPress={() => navigation.navigate('Forgot Password')}>
                  Forgot your password?
                </Button>
              </View> }
              <Button
                disabled={!isValid || isSubmitting}
                style={styles.signInButton}
                onPress={handleSubmit}
                size="giant">
                {isSubmitting ? 'SIGNING...' : 'SIGN IN'}
              </Button>
              <Button
                style={styles.signUpButton}
                appearance="ghost"
                status="basic"
                onPress={() => navigation.navigate('Register')}>
                Don't have an account? Create
              </Button>
            </FormLayout>
          </View>
        );
      }}
    </Formik>
  );
};

export default LoginScreen;
