import {StyleService} from '@ui-kitten/components';

const themedStyles = StyleService.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '47%',
  },
  mainContainer: {
    minHeight: '60%',
  },
  formContainer: {
    flex: 1,
    paddingTop: 32,
    paddingHorizontal: 16,
  },
  signInButton: {
    marginHorizontal: 16,
    borderRadius: 20,
    marginTop:10
  },
  signUpButton: {
    marginVertical: 12,
    marginHorizontal: 16,
  },
  forgotPasswordContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  passwordInput: {
    marginTop: 16,
  },
  forgotPasswordButton: {
    paddingHorizontal: 0,
  },
  formInput: {
    marginTop: 16,
  },
});

export default themedStyles;
