import React from 'react';
import {Formik} from 'formik';
import {object, string} from 'yup';
import {View} from 'react-native';
import {Button} from '@ui-kitten/components';

import {PersonIcon} from '../../../components/base/Icons';
import {FormLayout, Input} from '../../../components/base/FormControls';
import styles from './styles';

const initialValues = {
  username: '',
};

const validationSchema = object().shape({
  username: string().required('Username is required.'),
});

const LoginScreen = ({onSubmit, navigation}) => {
  return (
    <Formik
      validationSchema={validationSchema}
      initialValues={initialValues}
      onSubmit={onSubmit}>
      {({
        handleChange,
        handleBlur,
        handleSubmit,
        values,
        touched,
        errors,
        isValid,
        isSubmitting,
      }) => {
        const invalidUsername = touched.username && errors.username;
        return (
          <View>
            <FormLayout style={styles.formContainer}>
              <Input
                accessoryRight={PersonIcon}
                placeholder="Email/ Username"
                label="Email/Username"
                returnKeyType="next"
                value={values.username}
                disabled={isSubmitting}
                onBlur={handleBlur('username')}
                onChangeText={handleChange('username')}
                status={invalidUsername ? 'danger' : 'basic'}
                caption={invalidUsername ? errors.username : undefined}
              />

              <View style={styles.backPasswordContainer}>
                <Button
                  style={styles.backButton}
                  appearance="ghost"
                  status="basic"
                  onPress={() => navigation.navigate('Login')}>
                  Back
                </Button>
              </View>
              <Button
                disabled={!isValid || isSubmitting}
                style={styles.submitButton}
                onPress={handleSubmit}
                size="giant">
                {isSubmitting ? 'SUBMITING...' : 'SUBMIT'}
              </Button>
            </FormLayout>
          </View>
        );
      }}
    </Formik>
  );
};

export default LoginScreen;
