import React, {useCallback} from 'react';
import * as Animatable from 'react-native-animatable';
import {View} from 'react-native';
import {Text, Layout} from '@ui-kitten/components';
import ImageOverlay from '../../../components/base/ImageOverlay';
import KeyboardAvoidingView from '../../../components/base/KeyboardAvoidingView';
import Form from './Form';
import styles from './styles';

const ForgotPassword = ({navigation}) => {
  const onSubmit = useCallback(async (values, formikHelpers) => {
    formikHelpers.setSubmitting(true);
    try {
      navigation.navigate('Home');
    } catch (error) {
      formikHelpers.setSubmitting(false);
      if (error?.response?.status === 400) {
        formikHelpers.setFieldError(
          'username',
          'These credentials do not match our records.',
        );
      }
    }
  }, []);

  return (
    <KeyboardAvoidingView>
      <ImageOverlay
        style={styles.container}
        source={require('../../../assets/img/Forgot-password.png')}>
        <Animatable.View
          animation="bounceIn"
          duraton="1500"
          style={styles.container}>
          <Text category="h4" status="control">
            Find your account
          </Text>
        </Animatable.View>
      </ImageOverlay>
      <Layout style={styles.mainContainer}>
        <Animatable.View animation="fadeInUpBig">
          <Form onSubmit={onSubmit} navigation={navigation} />
        </Animatable.View>
      </Layout>
    </KeyboardAvoidingView>
  );
};

export default ForgotPassword;
