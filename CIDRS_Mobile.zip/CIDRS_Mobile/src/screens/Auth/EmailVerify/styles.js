import {StyleService} from '@ui-kitten/components';

const themedStyles = StyleService.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '40%',
  },
  mainContainer: {
    minHeight: '60%',
  },
  formContainer: {
    flex: 1,
    paddingTop: 32,
    paddingHorizontal: 16,
    minHeight: '100%',
  },
  submitButton: {
    alignItems: 'flex-end',
    marginHorizontal: 16,
    borderRadius: 20,
  },
  backPasswordContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  backButton: {
    paddingHorizontal: 0,
  },
  formInput: {
    marginTop: 16,
  },
});

export default themedStyles;
