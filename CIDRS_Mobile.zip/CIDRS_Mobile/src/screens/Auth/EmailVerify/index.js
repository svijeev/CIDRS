import React, {useCallback} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {View, ActivityIndicator} from 'react-native';
import {Text, Layout} from '@ui-kitten/components';
import ImageOverlay from '../../../components/base/ImageOverlay';
import KeyboardAvoidingView from '../../../components/base/KeyboardAvoidingView';
import Form from './Form';
import styles from './styles';
import {
  emailVerify,
  emailTokenResend,
  currentUser,
} from '../../../actions/auth';
import colors from '../../../constants/colors';

const ForgotPassword = ({navigation}) => {
  const dispatch = useDispatch();
  const {loading} = useSelector(state => state.auth);
  const onSubmit = useCallback(async (values, formikHelpers) => {
    formikHelpers.setSubmitting(true);
    try {
      var response = await dispatch(emailVerify(values));
      if (response?.errors) {
        formikHelpers.setSubmitting(false);
        formikHelpers.setFieldError('token', 'These token do not match.');
      }
      if (response.result) {
        dispatch(currentUser());
      }
    } catch (error) {}
  }, []);

  const onTokenResend = useCallback(async (values, formikHelpers) => {
    await dispatch(emailTokenResend());
  }, []);

  return (
    <KeyboardAvoidingView>
      <ImageOverlay
        style={styles.container}
        source={require('../../../assets/img/email.png')}>
        <View style={styles.container}>
          <Text category="h4" status="control">
            Verify Your Email
          </Text>

          {loading && <ActivityIndicator size="large" color={colors.primary} />}
        </View>
      </ImageOverlay>
      <Layout style={styles.mainContainer}>
        <Form
          onSubmit={onSubmit}
          onTokenResend={onTokenResend}
          navigation={navigation}
        />
      </Layout>
    </KeyboardAvoidingView>
  );
};

export default ForgotPassword;
