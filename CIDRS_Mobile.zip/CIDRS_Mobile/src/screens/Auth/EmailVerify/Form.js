import React from 'react';
import {Formik} from 'formik';
import {object, string} from 'yup';
import {View} from 'react-native';
import {Button} from '@ui-kitten/components';

import {FormLayout, Input} from '../../../components/base/FormControls';
import styles from './styles';

const initialValues = {
  token: '',
};

const validationSchema = object().shape({
  token: string().required('Token is required.').min(6).max(6),
});

const LoginScreen = ({onSubmit, onTokenResend, navigation}) => {
  return (
    <Formik
      validationSchema={validationSchema}
      initialValues={initialValues}
      onSubmit={onSubmit}>
      {({
        handleChange,
        handleBlur,
        handleSubmit,
        values,
        touched,
        errors,
        isValid,
        isSubmitting,
      }) => {
        const invalidToken = touched.token && errors.token;
        return (
          <View>
            <FormLayout style={styles.formContainer}>
              <Input
                maxLength={6}
                keyboardType="numeric"
                placeholder="Enter PIN number"
                returnKeyType="next"
                value={values.token}
                disabled={isSubmitting}
                onBlur={handleBlur('token')}
                onChangeText={handleChange('token')}
                status={invalidToken ? 'danger' : 'basic'}
                caption={invalidToken ? errors.token : undefined}
              />

              <View style={styles.backPasswordContainer}>
                <Button
                  style={styles.backButton}
                  appearance="ghost"
                  status="basic"
                  onPress={() => onTokenResend()}>
                  Resend
                </Button>
              </View>
              <Button
                disabled={!isValid || isSubmitting}
                style={styles.submitButton}
                onPress={handleSubmit}
                size="giant">
                {isSubmitting ? 'SUBMITING...' : 'SUBMIT'}
              </Button>
            </FormLayout>
          </View>
        );
      }}
    </Formik>
  );
};

export default LoginScreen;
