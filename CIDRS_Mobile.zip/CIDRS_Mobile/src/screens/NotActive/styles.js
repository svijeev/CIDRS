import {StyleService} from '@ui-kitten/components';

const themedStyles = StyleService.create({
  container: {
    flex: 1,
  },
});

export default themedStyles;
