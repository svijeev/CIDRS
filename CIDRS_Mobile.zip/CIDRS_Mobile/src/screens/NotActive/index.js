import React, {useContext} from 'react';
import {Image} from 'react-native';
import * as Animatable from 'react-native-animatable';
import {Layout, Text} from '@ui-kitten/components';
import Header from '../../components/shared/Header';
import styles from './styles';
import {ThemeContext} from '../../contexts/themeContext';
const View = ({navigation}) => {
  const themeState = React.useContext(ThemeContext);
  return (
    <Layout style={styles.container}>
      <Header navigation={navigation} title="" isBack={false} />
      <Animatable.View
        animation="bounceInUp"
        duraton="2500"
        style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
        <Image
          source={
            themeState.theme === 'dark'
              ? require('../../assets/img/Active-light.png')
              : require('../../assets/img/Active-dark.png')
          }
          style={{height: 250, width: 250}}
        />
        <Text category="h4" status="warning">
          Account Not Activated
        </Text>
      </Animatable.View>
    </Layout>
  );
};
export default View;
