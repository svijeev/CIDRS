import {StyleService} from '@ui-kitten/components';

const themedStyles = StyleService.create({
  formContainer: {
    paddingTop: 32,
    paddingHorizontal: 16,
  },
  signInButton: {
    marginTop: 30,
    marginHorizontal: 16,
    borderRadius: 20,
  },
  signUpButton: {
    marginVertical: 12,
    marginHorizontal: 16,
  },
  forgotPasswordContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  passwordInput: {
    marginTop: 16,
  },
  forgotPasswordButton: {
    paddingHorizontal: 0,
  },
  formInput: {
    marginTop: 16,
  },
});

export default themedStyles;
