import React, { useState, useEffect } from 'react';
import { SafeAreaView } from 'react-native';
import { ActivityIndicator, Layout, Button } from '@ui-kitten/components';
import { useSelector, useDispatch } from 'react-redux';
import Header from '../../../components/shared/Header';
import colors from '../../../constants/colors';
import Geolocation from '@react-native-community/geolocation';
import { addSurroundingSet } from '../../../actions/Reporting';
import Form from './Form'


const Index = ({ navigation }) => {
  const dispatch = useDispatch();
  const [location, setLocation] = useState({});

  const { surroundingSet, loading } = useSelector(state => state.reporting);

  useEffect(() => {
    Geolocation.getCurrentPosition(info => {
      setLocation({
        latitude: toString(info?.coords?.latitude),
        longitude: toString(info?.coords?.longitude),
      });
    });
  }, []);

   

  const onSubmit = React.useCallback(async (values, formikHelpers) => {
    formikHelpers.setSubmitting(true);

    try {
      const res = await dispatch(
        addSurroundingSet({
          image: values?.image,
          description: values?.description,
          latitude: location?.latitude,
          longitude: location?.longitude,
          relativeId: 1,
        }),
      );
     
      if (res?.succeeded) {
       await navigation.goBack();
      }

      if (res.errors) {
        formikHelpers.setSubmitting(false);
        if (error?.response?.status === 400) {
          formikHelpers.setFieldError('description', res.errors[0]);
        }
      }
    } catch (error) {
      formikHelpers.setSubmitting(false);
      if (error?.response?.status === 400) {
        formikHelpers.setFieldError('description', 'Description already exits.');
      }
    }
  }, []);



  if (loading) {
    return <ActivityIndicator size="large" color={colors.primary} />;
  }
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Header navigation={navigation} title="Surrounding Set" isBack={true} />
     
        <Form
          onSubmit={onSubmit}
          navigation={navigation}
          surroundingSet={surroundingSet}
        />
    
    </SafeAreaView>
  );
};
export default Index;
