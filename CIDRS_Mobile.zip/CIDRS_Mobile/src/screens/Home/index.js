import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { SafeAreaView, ActivityIndicator } from 'react-native';
import { Text,Button, Divider, List, ListItem, Avatar } from '@ui-kitten/components';
import Header from '../../components/shared/Header';
import { user as useUser } from '../../selectors/auth';

import { getReporting, setSurroundingSet, CoCompleteSurroundingSet } from '../../actions/Reporting';
import { getCOStartReporting} from '../../actions/workItems';
import colors from '../../constants/colors';
import {logout} from '../../actions/auth';

const Index = ({ route, navigation }) => {
  const dispatch = useDispatch();
  const user = useSelector(useUser);

  React.useEffect(() => {

    async function fetchData() {
      await dispatch(getCOStartReporting());
    }
    fetchData();
    
  }, [dispatch]);

  /* const logout = () => {
    const logoutAction = {
      type: PURGE,
      result: () => null,
    };
  
    return logoutAction;
  }; */
  

  // React.useEffect(() => {
  //   dispatch(getCOStartReporting());
  // }, [dispatch]);
  const { reports, loading } = useSelector(state => state.reporting);

  React.useEffect(() => {
    //if(reports?.id){
      
     dispatch(getReporting(1));

     //dispatch(getReporting(3));
   // }
    
  }, [dispatch]);

  const onSelectItem = async (item) => {
    await dispatch(setSurroundingSet(item));
    await navigation.navigate('ReportingApplication Details');
  };


  const completeSurrounding = async () => {
    const { succeeded } = await dispatch(CoCompleteSurroundingSet());
    if (succeeded) {
      dispatch(getCOStartReporting());
      dispatch(logout())

    }
  }

  const renderItemIcon = (props, item) => {
    return (
      <Avatar
        {...props}
        style={[props.style, { tintColor: null }]}
        shape='square'
        source={
          item?.imageUrl
            ? { uri: `http://vijeevcidrs-001-site1.htempurl.com/${item.imageUrl}` }
            : require('../../assets/img/logo.png')
        }
      />)
  }
  const renderItem = ({ item, index }) => (
    <ListItem
      title={item?.name}
      description={item?.description}
      accessoryLeft={(props) => renderItemIcon(props, item)}

      onPress={() => onSelectItem(item)}
    />
  );

  if (loading) {
    return <ActivityIndicator size="large" color={colors.primary} />;
  }
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Header navigation={navigation} title="Reporting" isBack={false} />
      {user?.isActive ?
      <>
      <List
        data={reports?.surroundingSets}
        ItemSeparatorComponent={Divider}
        renderItem={renderItem}
      />
      <Button
        style={{ alignItems: 'center', justifyContent: 'center', margin: 20 }}
        appearance="outline"
        onPress={() => completeSurrounding()}
      >
        COMPLETE
      </Button>
      </>
      
      :
      <Text style={{ color: 'red' }}>
      Your Registration is Completed, Please wait for the PHI to activate you, After activation You should relogin
    </Text>
      
    }
      
    </SafeAreaView>
  );
};
export default Index;
