import React from 'react';
import {View, StyleSheet, Image, ActivityIndicator} from 'react-native';

const SplashScreen = () => {
  return (
    <View style={styles.container}>
      <Image
        style={styles.avatar}
        source={require('../../assets/img/logo.png')}
      />
      <View style={styles.spinner}>
        <ActivityIndicator />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  avatar: {
    width: 150,
    height: 50,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  spinner: {
    marginTop: 15,
  },
});

export default SplashScreen;
