export default {
  primary: '#222B50',
};
