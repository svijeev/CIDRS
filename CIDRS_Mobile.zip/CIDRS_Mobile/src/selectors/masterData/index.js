import {createSelector} from 'reselect';

export const master = state => {
  return state.master;
};

export const loading = createSelector(master, state => {
  return state.loading;
});

export const districts = createSelector(master, state => {
  return state?.districts?.map(item => {
    return {
      id: item?.id,
      name: item?.name,
    };
  });
});
export const mohAreas = createSelector(master, state => {
  return state?.mohAreas?.map(item => {
    return {
      id: item?.id,
      name: item?.name,
    };
  });
});
