/** Bottom  Navigation Routes */
import HomeScreen from '../screens/Home';
import PoliceScreen from '../screens/Police';
import ChiefOccupantScreen from '../screens/ChiefOccupant';
import ComplaintScreen from '../screens/Complaint';
export const bottomNavigationRoutes = [
  {
    name: 'Home',
    screen: HomeScreen,
  },
  // {
  //   name: 'Police',
  //   screen: PoliceScreen,
  // },
  // {
  //   name: 'Chief Occupant',
  //   screen: ChiefOccupantScreen,
  // },
  // {
  //   name: 'Complaints',
  //   screen: ComplaintScreen,
  // },
];
/** End Bottom Navigation Routes  */

/** auth Navigation Routes */
import RegisterScreen from '../screens/Auth/Register';
import LoginScreen from '../screens/Auth/Login';
import ForgotPassword from '../screens/Auth/ForgotPassword';

export const authRoutes = [
  {
    name: 'Login',
    screen: LoginScreen,
  },
  {
    name: 'Register',
    screen: RegisterScreen,
  },
   {
    name: 'Forgot Password',
     screen: ForgotPassword,
   },
];
/** End Auth Navigation Routes  */

/** Bottom  Navigation Routes */
import PHIHomeScreen from '../screens/PHI/Home';
import PhiScreen from '../screens/PHI';
export const PhiBottomNavigationRoutes = [
  // {
  //   name: 'Phi Home',
  //   screen: PHIHomeScreen,
  // },
  {
    name: 'PHI',
    screen: PhiScreen,
  },
];
/** End Bottom Navigation Routes  */

/** App Navigation Routes */
import WorkItemsDetailScreen from '../screens/PHI/Details';
import ReportingScreen from '../screens/PHI/Reporting';
import ReportingCreateScreen from '../screens/PHI/Reporting/Create';
import ReportingApplicationDetails from '../screens/Home/ReportingApplicationDetails';

export const appRoutes = [
  {
    name: 'WorkItem Details',
    screen: WorkItemsDetailScreen,
  },
  {
    name: 'Reporting',
    screen: ReportingScreen,
  },
  {
    name: 'Reporting Create',
    screen: ReportingCreateScreen,
  },
  {
    name: 'ReportingApplication Details',
    screen: ReportingApplicationDetails,
  },
];
/** End aPP Navigation Routes  */
