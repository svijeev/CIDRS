import React from 'react';
import {useTheme} from '@ui-kitten/components';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import {bottomNavigationRoutes} from './routes';
import {ThemeContext} from '../contexts/themeContext';
import { useDispatch, useSelector } from 'react-redux';
import { getCOStartReporting } from '../actions/workItems';



import colors from '../constants/colors';

const Tab = createMaterialTopTabNavigator();

function BottomNavigation() {
  const dispatch = useDispatch();
  const theme = useTheme();
  const themeState = React.useContext(ThemeContext);


  
  return (
    <Tab.Navigator
      tabBarPosition="bottom"
      backBehavior="initialRoute"
      screenOptions={({route}) => ({
        tabBarIcon: ({focused, color, size}) => {
          let iconName;
          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          //   } else if (route.name === 'Police') {
          //     iconName = focused ? 'man' : 'man-outline';
          //   } else if (route.name === 'Chief Occupant') {
          //     iconName = focused ? 'people' : 'people-outline';
          // } else  if (route.name === 'Complaints') {
          //   iconName = focused ? 'documents' : 'documents-outline';
          }

          return <Ionicons name={iconName} size={19} color="#FFFFFF" />;
        },
      })}
      tabBarOptions={{
        style: {
          backgroundColor: colors.primary,
        },
        indicatorStyle: {
          borderBottomColor: '#FFFFFF',
          borderBottomWidth: 2,
        },

        activeTintColor: '#FFFFFF',
        inactiveTintColor: '#181725',
        showIcon: true,
        showLabel: false,
      }}>
      {bottomNavigationRoutes.map(route => {
        return (
          <Tab.Screen
            key={route.name}
            name={route.name}
            component={route.screen}
          />
        );
      })}
    </Tab.Navigator>
  );
}

export default BottomNavigation;
