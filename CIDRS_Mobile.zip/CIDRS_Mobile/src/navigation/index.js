import React from 'react';
import {useSelector} from 'react-redux';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';

import Sidebar from '../components/shared/Sidebar';
import BottomNavigation from './BottomNavigation';
import PHIBottomNavigation from './PHIBottomNavigation';
// import NotActive from '../screens/NotActive';
import {authRoutes, appRoutes} from './routes';
// import EmailVerify from '../screens/Auth/EmailVerify';
// import PhoneVerify from '../screens/Auth/PhoneVerify';

import {
  isAuthorized as useAuthorized,
  user as getUser,
} from '../selectors/auth';

const Stack = createStackNavigator();
const DrawerStack = createStackNavigator();
const Drawer = createDrawerNavigator();

const AppScreen = ({screen, name}) => {
  return (
    <DrawerStack.Navigator
      screenOptions={{
        headerShown: false,
      }}>
      <DrawerStack.Screen name={name} component={screen} />
    </DrawerStack.Navigator>
  );
};

const AppNavigator = () => {
  const user = useSelector(getUser);

  return (
    <>
      <Drawer.Navigator
        initialRouteName="Drawer"
        drawerStyle={{width: '80%'}}
        drawerContent={() => <Sidebar />}>
        <Drawer.Screen
          name="DetailsScreen"
          component={
            user?.userType != 2 ? BottomNavigation : PHIBottomNavigation
          }
        />
        {appRoutes.map(route => {
          return (
            <Drawer.Screen key={route.name} name={route.name}>
              {props => (
                <AppScreen {...props} name={route.name} screen={route.screen} />
              )}
            </Drawer.Screen>
          );
        })}
      </Drawer.Navigator>
    </>
  );
};
// const AuthNavigator = () => {
//   const user = useSelector(getUser);

//   return (
//     <>
//       <Drawer.Navigator
//         initialRouteName="Drawer"
//         drawerStyle={{width: '80%'}}
//         drawerContent={() => <Sidebar />}>
//         <Drawer.Screen
//           name="AuthScreen"
//           component={
//             user?.userType != 2 ? BottomNavigation : PHIBottomNavigation
//           }
//         />
//         <Drawer.Navigator
//           initialRouteName="Drawer"
//           drawerStyle={{width: '80%'}}
//           drawerContent={() => <Sidebar />}>
//           {user?.phoneNumberConfirmed === false ? (
//             <Drawer.Screen name="Phone Verification" component={PhoneVerify} />
//           ) : (
//             <Drawer.Screen name="Email Verification" component={EmailVerify} />
//           )}
//         </Drawer.Navigator>
//       </Drawer.Navigator>
//     </>
//   );
// };

const Navigation = () => {
  const isAuthorized = useSelector(useAuthorized);
  // const user = useSelector(getUser);
  return (
    <Stack.Navigator headerMode="none">
      {isAuthorized ? (
        // user?.emailConfirmed === true && user?.phoneNumberConfirmed === true ? (
          <Stack.Screen name="App" component={AppNavigator} />
        // ) 
        // : (
        //   <Stack.Screen name="Auth" component={AuthNavigator} />
        // )
      ) : (
        authRoutes.map(route => {
          return (
            <Stack.Screen
              key={route.name}
              name={route.name}
              component={route.screen}
            />
          );
        })
      )}
    </Stack.Navigator>
  );
};
export default Navigation;
