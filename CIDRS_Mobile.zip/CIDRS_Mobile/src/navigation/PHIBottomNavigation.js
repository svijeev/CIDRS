import React from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import {PhiBottomNavigationRoutes} from './routes';

import colors from '../constants/colors';

const Tab = createMaterialTopTabNavigator();

function BottomNavigation() {
  return (
    <Tab.Navigator
      tabBarPosition="bottom"
      backBehavior="initialRoute"
      screenOptions={({route}) => ({
        tabBarIcon: ({focused, color, size}) => {
          let iconName;
          // if (route.name === 'Phi Home') {
          //   iconName = focused ? 'home' : 'home-outline';
          // } else 
          if (route.name === 'PHI') {
            // iconName = focused ? 'medkit' : 'medkit-outline';
            iconName = focused ? 'home' : 'home-outline';
          }

          return <Ionicons name={iconName} size={19} color="#FFFFFF" />;
        },
      })}
      tabBarOptions={{
        style: {
          backgroundColor: colors.primary,
        },
        indicatorStyle: {
          borderBottomColor: '#FFFFFF',
          borderBottomWidth: 2,
        },

        activeTintColor: '#FFFFFF',
        inactiveTintColor: '#181725',
        showIcon: true,
        showLabel: false,
      }}>
      {PhiBottomNavigationRoutes.map(route => {
        return (
          <Tab.Screen
            key={route.name}
            name={route.name}
            component={route.screen}
          />
        );
      })}
    </Tab.Navigator>
  );
}

export default BottomNavigation;
