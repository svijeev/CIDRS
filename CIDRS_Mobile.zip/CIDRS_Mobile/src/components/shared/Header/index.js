import React from 'react';
import {DrawerActions} from '@react-navigation/routers';
import {
  TopNavigation,
  TopNavigationAction,
  Text,
  Divider,
  Icon,
} from '@ui-kitten/components';
import colors from '../../../constants/colors';
import Ionicons from 'react-native-vector-icons/Ionicons';

const ArrowBackIcon = props => <Icon {...props} name="arrow-back-outline" />;
const MenuIconOutline = props => <Icon {...props} name="menu-outline" />;

const Header = ({navigation, title, isBack}) => {
  return (
    <React.Fragment>
      <TopNavigation
        style={{backgroundColor: colors.primary}}
        title={() => (
          <Text category="h6" style={{fontWeight: 'bold', color: '#FFFFFF'}}>
            {title}
          </Text>
        )}
        alignment="start"
        accessoryLeft={() => (
          <TopNavigationAction
            icon={() =>
              isBack ? (
                <Ionicons name="arrow-back-outline" size={23} color="#FFFFFF" />
              ) : (
                <Ionicons name="menu-outline" size={23} color="#FFFFFF" />
              )
            }
            onPress={() => {
              if (isBack) {
                navigation.goBack();
              } else {
                navigation.dispatch(DrawerActions.openDrawer());
              }
            }}
          />
        )}
      />
      <Divider />
    </React.Fragment>
  );
};

export default Header;
