import React from 'react';
import {useSelector, useDispatch} from 'react-redux';
import VersionNumber from 'react-native-version-number';
import {SafeAreaView, View} from 'react-native';
import {
  Avatar,
  Button,
  Drawer,
  Layout,
  Text,
  StyleService,
  Card,
  Icon,
} from '@ui-kitten/components';
import Ionicons from 'react-native-vector-icons/Ionicons';

import {logout} from '../../../actions/auth';
import {ThemeContext} from '../../../contexts/themeContext';
import {user as getUser} from '../../../selectors/auth';

const Header = () => {
  const [isDark, setIsDark] = React.useState(false);
  const themeState = React.useContext(ThemeContext);
  const user = useSelector(getUser);

  return (
    <Layout style={headerStyle.container}>
      <Card>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <View style={{flexDirection: 'row'}}>
            <View>
              <Avatar
                style={headerStyle.avatar}
                shape="round"
                size="large"
                source={{uri: 'https://randomuser.me/api/portraits/men/43.jpg'}}
              />
            </View>
            <View
              style={{flexDirection: 'column', marginLeft: 10, marginTop: 5}}>
              <Text category="s1" status="basic" style={{fontWeight: 'bold'}}>
                {user?.fullName}
              </Text>
              <Text category="c1" appearance="hint">
                {user?.email}
              </Text>
              <Text category="c1" appearance="hint">
                {user?.phoneNumber}
              </Text>
            </View>
          </View>
          <View>
            {isDark ? (
              <Icon
                style={{width: 28, height: 28}}
                fill="#8F9BB3"
                name="moon-outline"
                onPress={() => [setIsDark(!isDark), themeState.toggleTheme()]}
              />
            ) : (
              <Icon
                style={{width: 28, height: 28}}
                fill="#8F9BB3"
                name="sun-outline"
                onPress={() => [setIsDark(!isDark), themeState.toggleTheme()]}
              />
            )}
          </View>
        </View>
      </Card>
    </Layout>
  );
};

const Footer = () => {
  const dispatch = useDispatch();
  const onLogout = React.useCallback(() => {
    dispatch(logout());
  }, [dispatch]);
  return (
    <Layout style={footerStyles.container}>
      <Button
        onPress={onLogout}
        style={footerStyles.button}
        status="basic"
        size="small"
        accessoryLeft={() => <Ionicons name="log-out-outline" size={23} />}>
        Logout
      </Button>
      <View style={footerStyles.infoContainer}>
        <View style={footerStyles.versionContainer}>
          <Text category="label">Version : </Text>
          <Text>
            {VersionNumber.appVersion}.{VersionNumber.buildVersion}
          </Text>
        </View>
        <Text category="c1">
          © {`${new Date().getFullYear()}`} RSV All Rights Reserved
        </Text>
      </View>
    </Layout>
  );
};

const Sidebar = ({navigation}) => {
  return (
    <>
      <SafeAreaView style={sidebarStyle.headerSafeAreaView}>
        <Layout style={sidebarStyle.container}>
          <Drawer
            style={sidebarStyle.container}
            header={() => <Header />}
            footer={() => <Footer navigation={navigation} />}
          />
        </Layout>
      </SafeAreaView>
    </>
  );
};

const footerStyles = StyleService.create({
  button: {
    borderRadius: 25,
    width: '100%',
  },
  container: {
    padding: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoContainer: {
    marginTop: 5,
    alignItems: 'center',
  },
  versionContainer: {
    alignItems: 'center',
    flexDirection: 'row',
  },
});

const headerStyle = StyleService.create({
  container: {
    height: '86%',
  },
  avatar: {
    width: 50,
    height: 50,
    marginTop: 5,
  },
});

const sidebarStyle = StyleService.create({
  container: {
    height: '100%',
    backgroundColor: 'color-basic-300',
  },
  headerSafeAreaView: {
    flex: 0,
    backgroundColor: 'color-basic-200',
  },
  safeAreaView: {
    flex: 1,
  },
});

export default Sidebar;
