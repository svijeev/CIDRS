import React from 'react';
import {Icon} from '@ui-kitten/components';

export const PersonIcon = props => <Icon name="person" {...props} />;
export const EyeIcon = props => <Icon name="eye" {...props} />;
export const EyeOffIcon = props => <Icon name="eye-off" {...props} />;
export const MailIcon = props => (
  <Icon name="mail" {...props} pack="ionicons" />
);
