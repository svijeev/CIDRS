import {
  withNextInputAutoFocusForm,
  withNextInputAutoFocusInput,
} from 'react-native-formik';
import {Input as UIInput, Layout} from '@ui-kitten/components';

export const Input = withNextInputAutoFocusInput(UIInput);
export const FormLayout = withNextInputAutoFocusForm(Layout);
