import React from 'react';
import {ImageBackground, StyleSheet, View} from 'react-native';

const DEFAULT_OVERLAY_COLOR = 'rgba(0, 0, 0, 0.45)';

export const OverlayFill = ({overlayColor}) => {
  return (
    <View
      style={[
        StyleSheet.absoluteFill,
        {backgroundColor: overlayColor || DEFAULT_OVERLAY_COLOR},
      ]}
    />
  );
};

const ImageOverlay = props => {
  const {style, children, ...imageBackgroundProps} = props;
  const {overlayColor, ...imageBackgroundStyle} = StyleSheet.flatten(style);

  return (
    <ImageBackground {...imageBackgroundProps} style={imageBackgroundStyle}>
      <OverlayFill overlayColor={overlayColor || DEFAULT_OVERLAY_COLOR} />
      {children}
    </ImageBackground>
  );
};

export default ImageOverlay;
