import React, {useState, useEffect} from 'react';
import PropTypes from 'prop-types';
import Icon from 'react-native-vector-icons/Ionicons';
import {
  ListItem,
  TopNavigation,
  TopNavigationAction,
  Input,
  Layout,
  Text,
} from '@ui-kitten/components';

import {View, Modal, FlatList} from 'react-native';
import {TextInput, StyleSheet, TouchableOpacity} from 'react-native';
import colors from '../../constants/colors';
import Ionicons from 'react-native-vector-icons/Ionicons';
function SearchDropdown({
  label,
  listItems,
  onSuccess,
  placeholder,
  defaultValue,
  subPlaceholder,
  caption,
  disabled = {isSubmitting},
}) {
  const [item, setItem] = useState(null);
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [focus, setFocus] = useState(false);

  const handleSearch = text => {
    setSearch(text);
    if (!text) return setItems(listItems);
    const searchedData = listItems?.filter(item => {
      return item?.name.toString().toLowerCase().includes(text.toLowerCase());
    });
    setItems(searchedData);
  };

  useEffect(() => {
    setItems(listItems);
    if (defaultValue) {
      setItem(listItems.find(o => o.id === defaultValue.id));
    }
  }, [listItems, defaultValue]);

  const title = item?.name.toString();
  return (
    <Layout style={{marginTop: 10}}>
      <Text category="s2" appearance="hint">
        {label}
      </Text>
      <TouchableOpacity
        style={[
          styles.textComponent,
          {
            borderColor: caption ? 'red' : '#E5EAF2',
            backgroundColor: disabled ? '#F7F9FC' : '#F7F9FC',
          },
        ]}
        onPress={() => setFocus(true)}>
        <View style={{width: '90%'}}>
          {item ? (
            <Text>{title}</Text>
          ) : (
            <Text style={{color: '#7b7b7b'}}>{placeholder}</Text>
          )}
        </View>
        <View style={{width: '10%'}}>
          <Icon size={20} color="#7b7b7b" name="chevron-down-outline" />
        </View>
      </TouchableOpacity>
      {caption && (
        <Text status="danger" category="s2">
          {caption}
        </Text>
      )}
      <Modal
        visible={focus}
        transparent={false}
        animationType="slide"
        onRequestClose={() => setFocus(false)}>
        <TopNavigation
          style={{backgroundColor: colors.primary}}
          alignment="center"
          title={() => (
            <Text category="h6" style={{color: 'white'}}>
              Select or Search
            </Text>
          )}
          accessoryLeft={() => (
            <TopNavigationAction
              icon={() => (
                <Ionicons
                  name="arrow-back-outline"
                  size={24}
                  color={'white'}
                  onPress={() => setFocus(false)}
                />
              )}
            />
          )}
          accessoryRight={() => (
            <TopNavigationAction
              icon={() => (
                <Ionicons
                  name="checkmark-outline"
                  size={24}
                  color={'white'}
                  onPress={() => setFocus(false)}
                />
              )}
            />
          )}
        />
        <View style={{padding: 10, flex: 1}}>
          <Input
            value={search}
            style={styles.textInput}
            placeholder={subPlaceholder}
            onChangeText={text => handleSearch(text)}
          />
          <FlatList
            data={items}
            renderItem={({item}) => {
              const title = item?.name.toString();
              return (
                <ListItem
                  title={title}
                  onPress={() => {
                    setItem(item);
                    onSuccess(item);
                    setFocus(false);
                  }}
                />
              );
            }}
            keyboardShouldPersistTaps={'always'}
            keyExtractor={item => item.id.toString()}
          />
        </View>
      </Modal>
    </Layout>
  );
}

SearchDropdown.propTypes = {
  onSuccess: PropTypes.func,
  listItems: PropTypes.array,
};

export default SearchDropdown;

const styles = StyleSheet.create({
  textComponent: {
    padding: 5,
    minHeight: 40,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  textInput: {
    height: 40,
    padding: 5,
    fontSize: 16,
    width: '100%',
    borderWidth: 1,
    paddingLeft: 10,
    marginBottom: 5,
    borderColor: '#7b7b7b',
  },
});
