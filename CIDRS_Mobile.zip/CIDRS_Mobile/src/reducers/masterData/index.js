import * as actionTypes from '../../actions/masterData/actionType';

const initialState = {
  loading: false,
  districts: [],
  mohAreas: [],
  error: {},
};

const masterDataReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.GET_DISTRACT_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_DISTRACT_SUCCESS:
      return {
        ...state,
        loading: false,
        districts: action.payload,
      };
    case actionTypes.GET_DISTRACT_REQUEST:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case actionTypes.GET_MOH_AREA_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_MOH_AREA_SUCCESS:
      return {
        ...state,
        loading: false,
        mohAreas: action.payload,
      };
    case action.GET_MOH_AREA_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    default:
      return state;
  }
};

export default masterDataReducer;
