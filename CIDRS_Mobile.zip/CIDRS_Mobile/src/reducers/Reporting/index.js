import * as actionTypes from '../../actions/Reporting/actionType';

const initialState = {
  loading: false,
  reports: {},
  error: {},
  reportId: '',
  chiefOccupantId: '',
  surroundingSet: {},
};

const ReportingReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.GET_REPORTING_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_REPORTING_SUCCESS:
      return {
        ...state,
        loading: false,
        reports: action.payload,
      };
    case actionTypes.GET_REPORTING_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case actionTypes.GET_REPORTING_CREATE_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_REPORTING_CREATE_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case actionTypes.GET_REPORTING_CREATE_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case actionTypes.GET_PASS_REPORTING_ID_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_PASS_REPORTING_ID_SUCCESS:
      return {
        ...state,
        loading: false,
        reportId: action.payload,
      };
    case actionTypes.GET_PASS_REPORTING_ID_FAIL:
      return {
        ...state,
        loading: false,
      };

    case actionTypes.SET_CHIEF_OCCUPANT_ID_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.SET_CHIEF_OCCUPANT_ID_SUCCESS:
      return {
        ...state,
        loading: false,
        chiefOccupantId: action.payload,
      };
    case actionTypes.SET_CHIEF_OCCUPANT_ID_FAIL:
      return {
        ...state,
        loading: false,
      };

    case actionTypes.SET_SURRONDING_SET_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.SET_SURRONDING_SET_SUCCESS:
      return {
        ...state,
        loading: false,
        surroundingSet: action.payload,
      };
    case actionTypes.SET_SURRONDING_SET_FAIL:
      return {
        ...state,
        loading: false,
      };

      case actionTypes.COMPLETE_SURRONDING_SET_REQUEST:
        return {
          ...state,
          loading: true,
        };
      case actionTypes.COMPLETE_SURRONDING_SET_SUCCESS:
        return {
          ...state,
          loading: false,
        };
      case actionTypes.COMPLETE_SURRONDING_SET_FAIL:
        return {
          ...state,
          loading: false,
        };

    default:
      return state;
  }
};

export default ReportingReducer;
