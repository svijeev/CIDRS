import camelcaseKeys from 'camelcase-keys';
import {
  LOGIN_SUCCESS,
  GET_REGISTER_FAIL,
  GET_REGISTER_REQUEST,
  GET_REGISTER_SUCCESS,
  GET_PHONE_VERIFY_FAIL,
  GET_PHONE_VERIFY_REQUEST,
  GET_PHONE_VERIFY_SUCCESS,
  GET_PHONE_VERIFY_CODR_RESEND_FAIL,
  GET_PHONE_VERIFY_CODR_RESEND_REQUEST,
  GET_PHONE_VERIFY_CODR_RESEND_SUCCESS,
  GET_CURRENT_USER_FAIL,
  GET_CURRENT_USER_REQUEST,
  GET_CURRENT_USER_SUCCESS,
  GET_EMAIL_VERIFY_CODR_RESEND_FAIL,
  GET_EMAIL_VERIFY_CODR_RESEND_REQUEST,
  GET_EMAIL_VERIFY_CODR_RESEND_SUCCESS,
  GET_EMAIL_VERIFY_REQUEST,
  GET_EMAIL_VERIFY_FAIL,
  GET_EMAIL_VERIFY_SUCCESS,
} from '../../actions/auth/actionType';

const initialState = {
  tokenType: 'Bearer',
  loading: false,
  user: {
    id: null,
    fullName: null,
    isActive: null,
    userName: null,
    email: null,
    phoneNumber: null,
    avatar: null,
    createdAt: null,
    userType: null,
    emailConfirmed: null,
    phoneNumberConfirmed: null,
  },
};

const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case LOGIN_SUCCESS:
      return {
        ...state,
        ...camelcaseKeys(action.response),
      };
    case GET_CURRENT_USER_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case GET_CURRENT_USER_SUCCESS:
      return {
        ...state,
        loading: false,
        user: {
          id: action.payload?.id,
          fullName: action.payload?.fullName,
          isActive: action.payload?.isActive,
          userName: action.payload?.userName,
          email: action.payload?.email,
          phoneNumber: action.payload?.phoneNumber,
          createdAt: action.payload?.createdAt,
          userType: action.payload?.userType,
        },
      };
    case GET_CURRENT_USER_FAIL:
      return {
        ...state,
        loading: false,
      };
    case GET_REGISTER_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case GET_REGISTER_SUCCESS:
      return {
        ...state,
        loading: false,
        ...camelcaseKeys(action.response),
      };
    case GET_REGISTER_FAIL:
      return {
        ...state,
        loading: false,
      };
    case GET_PHONE_VERIFY_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case GET_PHONE_VERIFY_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case GET_PHONE_VERIFY_FAIL:
      return {
        ...state,
        loading: false,
      };
    case GET_EMAIL_VERIFY_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case GET_EMAIL_VERIFY_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case GET_EMAIL_VERIFY_FAIL:
      return {
        ...state,
        loading: false,
      };

    case GET_PHONE_VERIFY_CODR_RESEND_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case GET_PHONE_VERIFY_CODR_RESEND_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case GET_PHONE_VERIFY_CODR_RESEND_FAIL:
      return {
        ...state,
        loading: false,
      };
    case GET_EMAIL_VERIFY_CODR_RESEND_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case GET_EMAIL_VERIFY_CODR_RESEND_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case GET_EMAIL_VERIFY_CODR_RESEND_FAIL:
      return {
        ...state,
        loading: false,
      };
    default:
      return state;
  }
};

export default authReducer;
