import {combineReducers} from 'redux';
import {persistReducer} from 'redux-persist';
import * as persist from '../config/persist';
import {PURGE} from 'redux-persist';

import authReducer from './auth';
import masterDataReducer from './masterData';
import workItemReducer from './workItems';
import ReportingReducer from './Reporting';

const appReducer = combineReducers({
  auth: persistReducer(persist.authToken, authReducer),
  master: masterDataReducer,
  workItems: workItemReducer,
  reporting: ReportingReducer,
});

const rootReducer = (state, action) => {
  if (action.type === PURGE) {
    return appReducer(undefined, action);
  }

  return appReducer(state, action);
};

export default rootReducer;
