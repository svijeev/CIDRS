import * as actionTypes from '../../actions/workItems/actionType';

const initialState = {
  loading: false,
  workItems: [],
  workItem: {},
  reports: {},
  error: {},
  workItemId: '',
};

const workItemReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.GET_ALL_WORKITEMS_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_ALL_WORKITEMS_SUCCESS:
      return {
        ...state,
        loading: false,
        workItems: action.payload,
      };
    case actionTypes.GET_ALL_WORKITEMS_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case actionTypes.GET_WORKITEM_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_WORKITEM_SUCCESS:
      return {
        ...state,
        loading: false,
        workItem: action.payload,
      };
    case actionTypes.GET_WORKITEM_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case actionTypes.GET_START_REPORTING_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_START_REPORTING_SUCCESS:
      return {
        ...state,
        loading: false,
        reports: action.payload,
      };
    case actionTypes.GET_START_REPORTING_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case actionTypes.GET_PASS_WORKITEM_ID_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.GET_PASS_WORKITEM_ID_SUCCESS:
      return {
        ...state,
        loading: false,
        workItemId: action.payload,
      };
    case actionTypes.GET_PASS_WORKITEM_ID_FAIL:
      return {
        ...state,
        loading: false,
      };
    default:
      return state;
  }
};

export default workItemReducer;
