﻿using System;

namespace CIDRS.Shared.Common.CurrentUser
{
    public class Class1
    {
    }
}
