﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIDRS.Shared.Utility.SmsManipulator.Models
{
    public class NotifyResponse
    {
        public string status { get; set; }
        public string data { get; set; }
    }
}
