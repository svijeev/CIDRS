﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CIDRS.Domain.Enums
{
    public enum WorkItemType
    {
        [Description("CO Registration")]
        CORegistration = 1,

        [Description("Reporting Application")]
        ReportingApplication = 2,

        
        
    }
}
