﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIDRS.Shared.Common.Pagination.Models
{
    public class PaginationOption
    {
        public int? Page { get; set; }
        public int? PageSize { get; set; }
    }
}
