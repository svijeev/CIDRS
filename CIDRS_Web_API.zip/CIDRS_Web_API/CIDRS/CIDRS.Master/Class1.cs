﻿using System;

namespace CIDRS.Master
{
    public class Class1
    {
    }
}
