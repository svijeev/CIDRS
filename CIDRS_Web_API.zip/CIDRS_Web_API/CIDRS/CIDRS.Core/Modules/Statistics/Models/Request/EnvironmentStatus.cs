﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIDRS.Core.Modules.Statistics.Models.Request
{
    public enum EnvironmentStatus
    {
        Clean = 1,
        Danger = 2,
        Any = 3
    }
}
