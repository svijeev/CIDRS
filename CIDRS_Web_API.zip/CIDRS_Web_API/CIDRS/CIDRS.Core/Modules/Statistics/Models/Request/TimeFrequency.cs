﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIDRS.Core.Modules.Statistics.Models.Request
{
    public enum TimeFrequency
    {
        Today = 1,
        Week = 2,
        Month = 3,
        Any = 4
    }
}
