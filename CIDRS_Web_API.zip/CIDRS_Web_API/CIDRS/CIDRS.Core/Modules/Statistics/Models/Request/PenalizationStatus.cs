﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIDRS.Core.Modules.Statistics.Models.Request
{
    public enum PenalizationStatus
    {
        Penalized = 1,
        Resolved = 2,
        Any = 3
    }
}
