﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIDRS.Core.Modules.Statistics.Models.Response
{
    public class EnvironmentStatistics
    {
        public Clean Clean { get; set; }
        public Danger Danger { get; set; }
    }
}
