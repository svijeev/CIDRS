﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIDRS.Core.Modules.Statistics.Models.Response
{
    public class PublicSurroundingStatistics
    {
        public int Today { get; set; }
        public int Week { get; set; }
        public int Month { get; set; }
    }
}
