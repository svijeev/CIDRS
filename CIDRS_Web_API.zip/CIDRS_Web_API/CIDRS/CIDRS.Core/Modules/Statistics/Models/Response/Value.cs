﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIDRS.Core.Modules.Statistics.Models.Response
{
    public class Value
    {
        public string Percentage { get; set; }
        public int Count { get; set; }
        public int TotalCount { get; set; }
    }
}
