﻿using System;

namespace CIDRS.Common
{
    public class Class1
    {
    }
}
