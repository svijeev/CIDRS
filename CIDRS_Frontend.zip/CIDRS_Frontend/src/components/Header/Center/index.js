import React from 'react';
import { Stack } from '@fluentui/react/lib/Stack';

function Center() {
  return <Stack horizontal></Stack>;
}

export default Center;
