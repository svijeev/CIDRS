import React from 'react';
import { Text } from '@fluentui/react/lib/Text';
import { Stack } from '@fluentui/react/lib/Stack';
import FabricPagination from 'office-ui-fabric-react-pagination';

function Pagination({ page, numberOfPages, totalItems, pageSize, onChange }) {
  return (
    <Stack
      horizontal
      verticalAlign="center"
      horizontalAlign="space-between"
      styles={{
        root: {
          color: 'white',
          backgroundColor: 'white',
        },
      }}>
      <FabricPagination
        onChange={onChange}
        totalPages={numberOfPages}
        currentPage={page}
      />
      <Stack
        horizontal
        tokens={{ childrenGap: 10 }}
        styles={{ root: { paddingRight: 15 } }}>
        <Text>Total: {totalItems}</Text>
        <Text>Per Page: {pageSize}</Text>
      </Stack>
    </Stack>
  );
}

export default Pagination;
