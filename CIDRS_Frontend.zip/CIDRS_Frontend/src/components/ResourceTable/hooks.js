import { useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import camelcaseKeys from 'camelcase-keys';
import { urlStringify } from 'lib/helpers';
import { loadResources } from 'actions/resources';

export function useResources({ url, resourceValues }) {
  const dispatch = useDispatch();
  const [items, setItems] = useState([]);
  const [isLoading, setLoading] = useState(false);
  const [pagination, setPagination] = useState({});

  const onChange = useCallback((items) => {
    setItems(items);
  }, []);

  const onLoadItems = useCallback(async () => {
    setLoading(true);
    try {
      const response = await dispatch(
        loadResources(`${url}?${urlStringify(resourceValues)}`),
      );
      if (response.results) {
        setItems(response.results);
      } else {
        setItems(response);
      }
      setPagination(
        camelcaseKeys({
          page: response?.page,
          pageSize: response?.pageSize,
          totalItems: response?.totalItems,
          numberOfPages: response?.numberOfPages,
          displayStart: response?.displayStart,
          displayEnd: response?.displayEnd,
          displayCount: response?.displayCount,
        }),
      );
    } catch (e) {}
    setLoading(false);
  }, [dispatch, url, resourceValues]);

  useEffect(() => {
    onLoadItems();
  }, [resourceValues, onLoadItems]);

  return { items, isLoading, onChange, pagination };
}
