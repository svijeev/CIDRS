import React from 'react';
import { Breadcrumb as DefaultBreadcrumb } from '@fluentui/react/lib/Breadcrumb';

function Breadcrumb({ items }) {
  return (
    <DefaultBreadcrumb
      styles={{
        root: {
          flex: 1,
          backgroundColor: '#fff',
          width: '100%',
          position: 'relative',
        },
      }}
      items={items}
      ariaLabel="Breadcrumb with custom divider icon"
      overflowAriaLabel="More links"
    />
  );
}

export default Breadcrumb;
