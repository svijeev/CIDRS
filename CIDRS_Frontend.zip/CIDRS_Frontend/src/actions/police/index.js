import { HTTP_REQUEST } from 'middleware/axios';

export function storeItem(values) {
  return {
    [HTTP_REQUEST]: {
      method: 'POST',
      url: 'api/v1/Police/new',
      data: {
        ...values,
      },
    },
  };
}
