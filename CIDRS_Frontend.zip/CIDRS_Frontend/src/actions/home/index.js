import { HTTP_REQUEST } from 'middleware/axios';

export function loadSummary() {
  return {
    [HTTP_REQUEST]: {
      method: 'GET',
      url: `api/v1/Statistics`,
    },
  };
}
