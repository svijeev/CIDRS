import { HTTP_REQUEST } from 'middleware/axios';

export function ApproveWorkItems(id) {
  return {
    [HTTP_REQUEST]: {
      method: 'POST',
      url: `api/v1/WorkItems/approve/${id}`,
    },
  };
}
export function RejectWorkItems(id) {
  return {
    [HTTP_REQUEST]: {
      method: 'POST',
      url: `api/v1/WorkItems/reject/${id}`,
    },
  };
}
export function reAssignWorkItem(id, values) {
  return {
    [HTTP_REQUEST]: {
      method: 'POST',
      url: `api/v1/WorkItems/re-assign`,
      data: {
        assigneeId: values?.assigneeId,
        policeId: values?.policeId,
        id: parseInt(id),
      },
    },
  };
}

export function loadItem(id) {
  return {
    [HTTP_REQUEST]: {
      url: `/api/v1/WorkItems/${id}`,
      useAuth: true,
    },
  };
}
export function RemarksActions(values) {
  return {
    [HTTP_REQUEST]: {
      data: values,
      method: 'POST',
      url: `api/v1/WorkItems/remark`,
    },
  };
}
