import { HTTP_REQUEST } from 'middleware/axios';

export function changePassword(values) {
  return {
    [HTTP_REQUEST]: {
      method: 'POST',
      url: '/api/v1/Identity/change-password',
      data: {
        ...values,
      },
    },
  };
}
