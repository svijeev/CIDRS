import { HTTP_REQUEST } from 'middleware/axios';

export function storeItem(values) {
  return {
    [HTTP_REQUEST]: {
      method: 'POST',
      url: 'api/v1/Phi/register-phi',
      data: {
        ...values,
      },
    },
  };
}
