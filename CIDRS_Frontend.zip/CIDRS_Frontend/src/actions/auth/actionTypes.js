export const LOGIN_SUCCESS = 'authentication/LOGIN_SUCCESS';
