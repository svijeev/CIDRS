import { PURGE } from 'redux-persist';
import { HTTP_REQUEST } from 'middleware/axios';
import * as actionTypes from './actionTypes';
import { authUrl } from 'config/env';

export function login(values) {
  return {
    [HTTP_REQUEST]: {
      method: 'POST',
      baseURL: authUrl,
      data: {
        username: values.username,
        password: values.password,
      },
      onSuccess: (response) => {
        return {
          response,
          type: actionTypes.LOGIN_SUCCESS,
        };
      },
    },
  };
}

export function logout() {
  return {
    type: PURGE,
    result: () => null,
  };
}

export function forgetPassword(values) {
  return {
    [HTTP_REQUEST]: {
      method: 'POST',
      url: `/api/v1/Identity/forgotPassword/${values.username}`,
    },
  };
}
