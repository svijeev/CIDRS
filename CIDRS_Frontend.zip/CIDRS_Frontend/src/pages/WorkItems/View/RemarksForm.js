import React from 'react';
import { withFormik } from 'formik';
import { Stack } from '@fluentui/react/lib/Stack';
import { TextField } from '@fluentui/react/lib/TextField';
import { PrimaryButton } from '@fluentui/react/lib/Button';
import { object, string } from 'yup';

function RemarksForm({
  values,
  handleChange,
  handleBlur,
  handleFocus,
  handleSubmit,

  touched,
  errors,
  isLoading,
}) {
  return (
    <Stack>
      <form action="" onSubmit={handleSubmit}>
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-lg12">
            <TextField
              name="remark"
              multiline
              rows={3}
              placeholder="enter your remark here..."
              value={values.remark}
              onChange={handleChange}
              onBlur={handleBlur}
              errorMessage={touched.remark && errors.remark}
              onFocus={handleFocus}
              styles={{ root: { marginTop: '10px', border: 0 } }}
            />
          </div>
        </div>
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-lg12 pull-right">
            <PrimaryButton
              disabled={isLoading}
              className="primary-btn"
              onClick={handleSubmit}
              text={isLoading ? 'Loading...' : 'Add Remakrs'}
            />
          </div>
        </div>
      </form>
    </Stack>
  );
}
export default withFormik({
  validationSchema: object().shape({
    remark: string().required('Remarks is a required field.'),
  }),
  handleSubmit: (values, { props, ...actions }) => {
    props.onSubmit(values, actions);
  },
  enableReinitialize: true,
  mapPropsToValues: ({ item }) => {
    return {
      edit: !!item,
      remark: item ? item.remark : '',
      id: item ? item.id : '',
    };
  },
})(RemarksForm);
