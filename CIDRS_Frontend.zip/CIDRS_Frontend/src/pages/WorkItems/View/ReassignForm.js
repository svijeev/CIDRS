import React from 'react';
import PropTypes from 'prop-types';
import { DefaultButton, PrimaryButton } from '@fluentui/react/lib/Button';
import { withFormik } from 'formik/dist/index';
import { object } from 'yup';
import { Stack } from '@fluentui/react/lib/Stack';
import SearchDropdown from 'components/SearchDropdown';

function ReassignForm({
  values,
  errors,
  isValid,
  onCancel,
  handleSubmit,
  isSubmitting,
  setFieldValue,
  setFieldTouched,
  touched,
  workItem,
}) {
  const sectionStackTokens = { childrenGap: 10 };

  return (
    <form onSubmit={handleSubmit} className="full-flex">
      <Stack
        verticalAlign="space-between"
        styles={{ root: { flex: 1, height: '100%' } }}>
        <Stack>
          <SearchDropdown
            name="phi"
            label="Assignee"
            placeholder="choose a phi"
            value={values.phi || ''}
            required={true}
            disabled={isSubmitting}
            getText={(item) => item.fullName}
            getValue={(item) => item.id}
            url={`api/v1/Phi/lookup?districtId=${workItem?.chiefOccupant?.district?.id}&mohAreaId=${workItem?.chiefOccupant?.mohArea?.id}`}
            onBlur={() => setFieldTouched('phi')}
            errorMessage={touched.phi && errors.phi}
            onChange={(id) => setFieldValue('phi', id)}
          />
          <SearchDropdown
            name="police"
            label="Police"
            placeholder="choose a police"
            value={values.police || ''}
            required={true}
            disabled={isSubmitting}
            getText={(item) => item.fullName}
            getValue={(item) => item.id}
            url={`api/v1/Police/lookup?mohAreaId=${workItem?.chiefOccupant?.mohArea?.id}`}
            onBlur={() => setFieldTouched('phi')}
            errorMessage={touched.police && errors.police}
            onChange={(id) => setFieldValue('police', id)}
          />
        </Stack>
        <Stack.Item align="end" tokens={sectionStackTokens}>
          <Stack horizontal>
            <PrimaryButton
              onClick={handleSubmit}
              disabled={!isValid}
              styles={{ root: { marginRight: '5px' } }}
              text={isSubmitting ? 'Loading...' : 'Submit'}
            />
            <DefaultButton
              text="Cancel"
              onClick={onCancel}
              disabled={isSubmitting}
            />
          </Stack>
        </Stack.Item>
      </Stack>
    </form>
  );
}

ReassignForm.propTypes = {
  loading: PropTypes.bool,
  onSubmit: PropTypes.func,
  onCancel: PropTypes.func,
};

export default withFormik({
  validationSchema: object().shape({
    phi: object().required('Assignee is a required field'),
    police: object().required('Police is a required field'),
  }),
  mapPropsToValues: ({ item }) => ({
    edit: !!item,
    id: item ? item.id : '',
    dish: item ? item.dish : '',
  }),
  handleSubmit: (values, { props, ...actions }) => {
    props.onSubmit(
      {
        ...values,
        assigneeId: values?.phi ? values?.phi?.id : null,
        policeId: values?.police ? values?.police?.id : null,
      },
      actions,
    );
  },
})(ReassignForm);
