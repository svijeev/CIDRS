import { useState, useEffect, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import {
  ApproveWorkItems,
  RejectWorkItems,
  loadItem,
  reAssignWorkItem,
  RemarksActions,
} from 'actions/WorkItem';
// List Item
export function useLoadItem(url) {
  const [item, setItem] = useState(null);
  const [isLoading, setLoading] = useState(false);

  const dispatch = useDispatch();
  const onLoadItem = useCallback(async () => {
    setLoading(true);
    try {
      const response = await dispatch(loadItem(url));
      setItem(response.result);
    } catch (e) {}
    setLoading(false);
  }, [dispatch, url]);

  useEffect(() => {
    onLoadItem();
  }, [onLoadItem]);

  return { item, isLoading, onLoadItem };
}

export function useUpdateStatus({ id, onSuccess, closePanel }) {
  const dispatch = useDispatch();

  const onApproveWorkItems = useCallback(
    async (actions) => {
      try {
        const response = await dispatch(ApproveWorkItems(id));
        if (response.succeeded) {
          closePanel(true);
          onSuccess();
        }
      } catch (e) {}
    },
    [dispatch, id, closePanel, onSuccess],
  );
  const onRejectWorkItems = useCallback(
    async (actions) => {
      try {
        const response = await dispatch(RejectWorkItems(id));
        if (response.succeeded) {
          closePanel(true);
          onSuccess();
        }
      } catch (e) {}
    },
    [dispatch, id, closePanel, onSuccess],
  );

  return { onApproveWorkItems, onRejectWorkItems };
}

export function useReAssignItem({ id, onSuccess, setOpen }) {
  const dispatch = useDispatch();

  const reAssignItem = useCallback(
    async (values, actions) => {
      actions.setSubmitting(true);
      try {
        const response = await dispatch(reAssignWorkItem(id, values));
        if (response.succeeded) {
          setOpen(false);
          onSuccess();
        }
      } catch (e) {
        if (e.errors) {
          actions.setErrors(e.errors);
        }
        actions.setSubmitting(false);
      }
    },
    [dispatch, id, setOpen, onSuccess],
  );

  return { reAssignItem };
}
export function useSore({  onSuccess }) {
  const dispatch = useDispatch();

  const onStore = useCallback(
    async (values, actions) => {
      try {
        await dispatch(RemarksActions(values));
        onSuccess();
      } catch (e) {}

      actions.resetForm();
    },
    [dispatch, onSuccess],
  );
  return { onStore };
}
