import React, { useMemo, useState } from 'react';
import {
  SelectionMode,
  Dialog,
  PrimaryButton,
  DialogFooter,
  DialogType,
  Persona,
  PersonaSize,
} from '@fluentui/react/lib';
import { Stack } from '@fluentui/react/lib/Stack';
import { Text } from '@fluentui/react/lib/Text';
import { Image } from '@fluentui/react/lib/Image';
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';
import { ShimmeredDetailsList } from '@fluentui/react/lib/ShimmeredDetailsList';
import ReassignForm from './ReassignForm';
import RemarksForm from './RemarksForm';
import {
  ScrollablePane,
  ScrollbarVisibility,
} from '@fluentui/react/lib/ScrollablePane';
import Breadcrumb from 'components/Breadcrumb';
import RichModal from 'components/RichModal';
// import { useResource } from 'hooks/resources';
import * as routes from 'constants/routes';
import { DefaultButton } from '@fluentui/react';
import moment from 'moment';
import { baseUrl, googleMapKey } from '../../../config/env';
import Map from 'components/Map';
import {
  useLoadItem,
  useUpdateStatus,
  useReAssignItem,
  useSore,
} from './hooks';

export const columns = [
  {
    key: 'identifier',
    name: 'Identifier',
    fieldName: 'identifier',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'number',
    isPadded: true,
  },
  {
    key: 'type',
    name: 'Type',
    fieldName: 'type',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => {
      if (item.type === 1) return 'New';
      if (item.type === 2) return 'Reject';
      if (item.type === 3) return 'Approve';
      if (item.type === 4) return 'Abandon';
      if (item.type === 5) return 'Assign';
    },
  },
  {
    key: 'assignTo',
    name: 'Assign To',
    fieldName: 'assignTo',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => {
      return item?.assignTo ? item?.assignTo?.fullName : '-';
    },
  },
  {
    key: 'createdAt',
    name: 'Created AT',
    fieldName: 'createdAt',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => moment(item?.createdAt).format('LL'),
  },
];

function Show({ history, match }) {
  const { id } = match.params;
  // const { isLoading, item } = useResource(`api/v1/WorkItems/${id}`);
  const { isLoading, item, onLoadItem } = useLoadItem(id);
  const onSuccess = () => onLoadItem();

  const [hideDialog, setHideDialog] = useState(true);
  const [dialogType, setDialogType] = useState('');
  const [isOpen, setOpen] = useState(false);

  const { onApproveWorkItems, onRejectWorkItems } = useUpdateStatus({
    id,
    onSuccess,
    closePanel: setHideDialog,
  });
  const { reAssignItem } = useReAssignItem({
    id,
    onSuccess,
    setOpen: setOpen,
  });
  const { onStore } = useSore({ onSuccess });

  const handleSubmit = () => {
    if (dialogType === 'Approve') {
      onApproveWorkItems();
    }
    if (dialogType === 'Reject') {
      onRejectWorkItems();
    }
  };

  const breadcrumbItems = useMemo(() => {
    const items = [
      {
        text: 'Work Items',
        key: 'index',
        onClick: () => history.push(routes.WORK_ITEMS),
      },
    ];

    if (item) {
      items.push({
        text: item.identifier,
        key: 'show',
        isCurrentItem: true,
      });
    }

    return items;
  }, [item, history]);

  if (isLoading) {
    return (
      <Stack styles={{ root: { flex: 1, justifyContent: 'center' } }}>
        <Spinner label="Loading..." size={SpinnerSize.large} />
      </Stack>
    );
  }
  if (!item) {
    return null;
  }

  return (
    <Stack className="inner-page-panel">
      <Stack>
        <Breadcrumb items={breadcrumbItems} />
      </Stack>
      <Stack className="show-panel">
        <ScrollablePane scrollbarVisibility={ScrollbarVisibility.auto}>
          <Stack className="show-panel-button">
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg12 pull-right">
                  <DefaultButton
                    className="primary-btn"
                    text="Back"
                    iconProps={{ iconName: 'Back' }}
                    onClick={() => history.goBack()}
                  />
                </div>
              </div>
            </div>
          </Stack>
          <Stack className="show-panel-data">
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg2 row-item-label">
                  Identifier
                </div>
                <div className="ms-Grid-col ms-lg4 row-item-data">
                  <span>{item?.identifier}</span>
                </div>
                <div className="ms-Grid-col ms-lg2 row-item-label">
                  created At
                </div>
                <div className="ms-Grid-col ms-lg4 row-item-data">
                  <span>{moment(item?.createdAt).format('LL')}</span>
                </div>
              </div>
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg2 row-item-label">Type</div>
                <div className="ms-Grid-col ms-lg4 row-item-data">
                  <span>
                    {item?.type === 1
                      ? 'CO Registration'
                      : item?.type === 2
                      ? 'Reporting Application'
                      : 'None'}
                  </span>
                </div>
                <div className="ms-Grid-col ms-lg2 row-item-label">Status</div>
                <div className="ms-Grid-col ms-lg4 row-item-data">
                  {item?.status === 1 ? (
                    <span style={{ color: '#FFFC00' }}>Active</span>
                  ) : null}
                  {item?.status === 2 ? (
                    <span style={{ color: 'red' }}>Rejected</span>
                  ) : null}
                  {item?.status === 3 ? (
                    <span style={{ color: 'green' }}>Approved</span>
                  ) : null}
                  {item?.status === 4 ? (
                    <span style={{ color: '#EC5853' }}>Abandoned</span>
                  ) : null}
                </div>
              </div>
            </div>
          </Stack>
          {item?.chiefOccupant && (
            <>
              <Stack className="section-heading">
                <Text variant="large">chief Occupant Details</Text>
              </Stack>
              <div className="ms-Grid" dir="ltr">
                <div className="ms-Grid-row">
                  <div className="ms-Grid-col ms-lg2 row-item-label">
                    Identifier
                  </div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>{item?.chiefOccupant?.identifier}</span>
                  </div>
                  <div className="ms-Grid-col ms-lg2 row-item-label">
                    Full Name
                  </div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>{item?.chiefOccupant?.fullName}</span>
                  </div>
                </div>
                <div className="ms-Grid-row">
                  <div className="ms-Grid-col ms-lg2 row-item-label">
                    Phone Number
                  </div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>{item?.chiefOccupant?.phoneNumber}</span>
                  </div>
                  <div className="ms-Grid-col ms-lg2 row-item-label">
                    Moh Area
                  </div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>{item?.chiefOccupant?.mohArea?.name}</span>
                  </div>
                </div>
                <div className="ms-Grid-row">
                  <div className="ms-Grid-col ms-lg2 row-item-label">
                    District
                  </div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>{item?.chiefOccupant?.district?.name}</span>
                  </div>
                  <div className="ms-Grid-col ms-lg2 row-item-label">
                    Address
                  </div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>{item?.chiefOccupant?.address}</span>
                  </div>
                </div>
              </div>
            </>
          )}

          {item?.application && (
            <>
              <Stack className="section-heading m-l-10 ">
                <Text variant="large">Application Details</Text>
              </Stack>
              <div className="ms-Grid" dir="ltr">
                <div className="ms-Grid-row">
                  <div className="ms-Grid-col ms-lg2 row-item-label">
                    Identifier
                  </div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>{item?.application?.identifier}</span>
                  </div>
                </div>
                <div className="ms-Grid-row">
                  <div className="ms-Grid-col ms-lg2 row-item-label">Type</div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>
                      {item?.application?.type === 1 ? 'Base' : null}
                      {item?.application?.type === 2
                        ? 'Home Surrounding Alerts'
                        : null}
                      {item?.application?.type === 3
                        ? 'Public Surrounding Complaints'
                        : null}
                    </span>
                  </div>
                  <div className="ms-Grid-col ms-lg2 row-item-label">
                    Created
                  </div>
                  <div className="ms-Grid-col ms-lg4 row-item-data">
                    <span>
                      {moment(item?.application?.createdAt).format('LL')}
                    </span>
                  </div>
                </div>
              </div>

              <Stack className="section-heading m-l-10 ">
                <Text variant="large"> Surrounding Sets</Text>
              </Stack>
              {item?.application?.type === 2 &&
                item?.application?.surroundingSets?.map((item) => {
                  return (
                    <div className="ms-Grid" dir="ltr">
                      <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-lg2 row-item-label">
                          Name
                        </div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <span>{item?.name}</span>
                        </div>
                        <div className="ms-Grid-col ms-lg2 row-item-label">
                          Description
                        </div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <span>{item?.description}</span>
                        </div>
                      </div>
                      <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-lg2 row-item-label"></div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <Image
                            height={300}
                            style={{ width: '100%' }}
                            src={baseUrl + item?.imageUrl}
                            alt={item?.name}
                          />
                        </div>
                        <div className="ms-Grid-col ms-lg2 row-item-label"></div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <Image
                            height={300}
                            style={{ width: '100%' }}
                            src={
                              baseUrl + item?.relativeSurroundingSet?.imageUrl
                            }
                            alt={item?.name}
                          />
                        </div>
                      </div>
                      <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-lg2 row-item-label"></div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <Map
                            isMarkerShown
                            googleMapURL={`https://maps.googleapis.com/maps/api/js?key=${googleMapKey}&v=3.exp&libraries=geometry,drawing,places`}
                            loadingElement={<div style={{ height: `100%` }} />}
                            containerElement={
                              <div style={{ height: `300px` }} />
                            }
                            mapElement={<div style={{ height: `100%` }} />}
                            markedPos={
                              item?.latitude && item?.longitude
                                ? {
                                    lat: parseFloat(item?.latitude),
                                    lng: parseFloat(item?.longitude),
                                  }
                                : null
                            }
                          />
                        </div>
                        <div className="ms-Grid-col ms-lg2 row-item-label"></div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <Map
                            isMarkerShown
                            googleMapURL={`https://maps.googleapis.com/maps/api/js?key=${googleMapKey}&v=3.exp&libraries=geometry,drawing,places`}
                            loadingElement={<div style={{ height: `100%` }} />}
                            containerElement={
                              <div style={{ height: `300px` }} />
                            }
                            mapElement={<div style={{ height: `100%` }} />}
                            markedPos={
                              item?.relativeSurroundingSet?.latitude &&
                              item?.relativeSurroundingSet?.longitude
                                ? {
                                    lat: parseFloat(
                                      item?.relativeSurroundingSet?.latitude,
                                    ),
                                    lng: parseFloat(
                                      item?.relativeSurroundingSet?.longitude,
                                    ),
                                  }
                                : null
                            }
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}

              {item?.application?.type === 3 &&
                item?.application?.surroundingSets?.map((item) => {
                  return (
                    <div className="ms-Grid" dir="ltr">
                      <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-lg2 row-item-label">
                          Name
                        </div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <span>{item?.name}</span>
                        </div>
                        <div className="ms-Grid-col ms-lg2 row-item-label">
                          Description
                        </div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <span>{item?.description}</span>
                        </div>
                      </div>
                      <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-lg2 row-item-label"></div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <Image
                            height={300}
                            style={{ width: '100%' }}
                            src={baseUrl + item?.imageUrl}
                            alt={item?.name}
                          />
                        </div>
                        <div className="ms-Grid-col ms-lg2 row-item-label"></div>
                        <div className="ms-Grid-col ms-lg4 row-item-data">
                          <Map
                            isMarkerShown
                            googleMapURL={`https://maps.googleapis.com/maps/api/js?key=${googleMapKey}&v=3.exp&libraries=geometry,drawing,places`}
                            loadingElement={<div style={{ height: `100%` }} />}
                            containerElement={
                              <div style={{ height: `300px` }} />
                            }
                            mapElement={<div style={{ height: `100%` }} />}
                            markedPos={
                              item.latitude && item.longitude
                                ? {
                                    lat: parseFloat(item?.latitude),
                                    lng: parseFloat(item?.longitude),
                                  }
                                : null
                            }
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
            </>
          )}
          <Stack className="section-heading m-l-10 ">
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg6 pull-left">
                  <Text variant="large"> workItem Actions</Text>
                </div>
                {item?.status === 1 && (
                  <div className="ms-Grid-col ms-lg6 pull-right">
                    {item?.application?.type === 3 && (
                      <DefaultButton
                        style={{ marginRight: 10 }}
                        className="primary-btn  btn-success"
                        text="Approve"
                        iconProps={{ iconName: 'Assign' }}
                        onClick={() => [
                          setHideDialog(false),
                          setDialogType('Approve'),
                        ]}
                      />
                    )}
                    {item?.application?.type === 2 && (
                      <>
                        <DefaultButton
                          style={{ marginRight: 10 }}
                          className="primary-btn  btn-success"
                          text="Approve"
                          iconProps={{ iconName: 'Assign' }}
                          onClick={() => [
                            setHideDialog(false),
                            setDialogType('Approve'),
                          ]}
                        />
                        <DefaultButton
                          style={{ marginRight: 10 }}
                          className="primary-btn  btn-danger"
                          text="Reject"
                          iconProps={{ iconName: 'Assign' }}
                          onClick={() => [
                            setHideDialog(false),
                            setDialogType('Reject'),
                          ]}
                        />
                      </>
                    )}

                    {item?.chiefOccupant && (
                      <DefaultButton
                        className="primary-btn  btn-secondary"
                        text="Reassign"
                        iconProps={{ iconName: 'Assign' }}
                        onClick={() => setOpen(true)}
                      />
                    )}
                  </div>
                )}
              </div>
            </div>
          </Stack>
          <div className="ms-Grid" dir="ltr">
            <div className="ms-Grid-row" style={{ margin: 15 }}>
              <ShimmeredDetailsList
                setKey="items"
                items={item?.workItemActions || []}
                columns={columns}
                selectionMode={SelectionMode.none}
                enableShimmer={!item?.workItemActions}
                ariaLabelForShimmer="Content is being fetched"
                ariaLabelForGrid="Item details"
              />
            </div>
          </div>
          <div className="show-panel-block">
            <Stack className="show-panel-block-heading">
              <Text variant="large">Remarks</Text>
            </Stack>
            <Stack styles={{ root: { height: 250, position: 'relative' } }}>
              <ScrollablePane scrollbarVisibility={'auto'}>
                {item?.workItemRemarks?.map((values) => {
                  return (
                    <>
                      <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-lg12">
                          <Persona
                            styles={{ root: { marginTop: '30px' } }}
                            size={PersonaSize.size48}
                            imageInitials={'WR'}
                            className="ms-Persona-comments">
                            <span
                              style={{ fontSize: '13px', color: '#868585' }}>
                              {values?.ownerName}
                              <span
                                style={{ fontSize: '12px', color: '#868585' }}>
                                {` (${moment.utc(values.createdAt).fromNow()})`}
                              </span>
                            </span>
                            <span
                              style={{ fontSize: '14px', paddingTop: '5px' }}>
                              {values?.remark}
                            </span>
                          </Persona>
                        </div>
                      </div>
                    </>
                  );
                })}
                {item?.status === 1 && (
                  <RemarksForm onSubmit={onStore} item={item} />
                )}
              </ScrollablePane>
            </Stack>
          </div>

          <Dialog
            hidden={hideDialog}
            onDismiss={() => setHideDialog(false)}
            dialogContentProps={{
              type: DialogType.normal,
              title: `${dialogType}`,
              subText: `Are you sure want to ${dialogType} this item?`,
            }}
            modalProps={{
              isBlocking: false,
              styles: { main: { maxWidth: 450 } },
            }}>
            <DialogFooter>
              <PrimaryButton text="Yes" onClick={() => handleSubmit()} />
              <DefaultButton
                text="Cancel"
                onClick={() => setHideDialog(true)}
              />
            </DialogFooter>
          </Dialog>
          <RichModal
            isOpen={isOpen}
            icon="Assign"
            title="Reassign Work Items"
            description="Choose a Police and assignee to reasign work items.">
            <ReassignForm
              workItem={item}
              onCancel={() => setOpen(false)}
              onSubmit={reAssignItem}
            />
          </RichModal>
        </ScrollablePane>
      </Stack>
    </Stack>
  );
}

export default Show;
