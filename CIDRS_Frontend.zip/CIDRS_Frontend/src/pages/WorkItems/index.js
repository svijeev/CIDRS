import React from 'react';
import padStart from 'lodash-es/padStart';
import { Dropdown, DefaultButton } from '@fluentui/react/lib';
import { Stack } from '@fluentui/react/lib/Stack';
import Breadcrumb from 'components/Breadcrumb';
import ResourceTable from 'components/ResourceTable';
import * as routes from 'constants/routes';
import moment from 'moment';
import { searchRoute, urlSearch } from '../../lib/helpers';

const breadcrumbItems = [
  {
    text: 'Work Items',
    key: 'index',
    isCurrentItem: true,
  },
];

export const columns = [
  {
    key: 'identifier',
    name: 'Identifier',
    fieldName: 'identifier',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'number',
    isPadded: true,
  },
  {
    key: 'type',
    name: 'Type',
    fieldName: 'type',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => {
      if (item.type === 1) return 'CO Registration';
      if (item.type === 2) return 'Reporting Application';
    },
  },
  {
    key: 'status',
    name: 'Status',
    fieldName: 'status',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => {
      if (item.status === 1) return 'Active';
      if (item.status === 2) return 'Rejected';
      if (item.status === 3) return 'Approved';
      if (item.status === 4) return 'Abandoned';
    },
  },
  {
    key: 'chiefOccupant',
    name: 'Chief Occupant',
    fieldName: 'chiefOccupant',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => padStart(item?.chiefOccupant?.fullName),
  },
  {
    key: 'createdAt',
    name: 'Created AT',
    fieldName: 'createdAt',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => moment(item?.createdAt).format('LL'),
  },
];

function Customer({ history, location }) {
  const { isActive = '', type = '' } = urlSearch(location.search);
  const handlerClear = () => {
    history.push(searchRoute(location, { type: '' }));
    history.push(searchRoute(location, { isActive: '' }));
  };

  return (
    <Stack className="inner-page-panel">
      <Breadcrumb items={breadcrumbItems} />
      <Stack
        horizontal
        verticalAlign="center"
        tokens={{ padding: '5px 10px 5px 10px' }}>
        <Dropdown
          styles={{
            root: { width: 300, float: 'right', paddingRight: '5px' },
          }}
          placeholder="Select an option"
          label="Active"
          value={isActive}
          options={[
            { key: 'true', text: 'Yes' },
            { key: 'false', text: 'No' },
          ]}
          onChanged={(value) => {
            history.push(searchRoute(location, { isActive: value.key }));
          }}
        />
        <Dropdown
          styles={{
            root: { width: 300, float: 'right', paddingRight: '5px' },
          }}
          placeholder="Select an option"
          label="Type"
          value={type}
          options={[
            { key: 1, text: 'CO Registration' },
            { key: 2, text: 'Reporting Application' },
          ]}
          onChanged={(value) =>
            history.push(searchRoute(location, { type: value.key }))
          }
        />
        <DefaultButton
          style={{ marginTop: 28 }}
          text="Clear"
          iconProps={{ iconName: 'Refresh' }}
          onClick={() => handlerClear()}
        />
      </Stack>
      <ResourceTable
        url="api/v1/WorkItems"
        columns={columns}
        viewRoute={(item) => routes.WORK_ITEMS_SHOW.replace(':id', item.id)}
        disableActions={{
          view: false,
          edit: true,
          delete: true,
        }}
      />
    </Stack>
  );
}

export default Customer;
