import React from 'react';
import { withFormik } from 'formik';
import { object, string } from 'yup';
import { Stack } from '@fluentui/react/lib/Stack';
import { TextField } from '@fluentui/react/lib/TextField';
import { PrimaryButton } from '@fluentui/react/lib/Button';
import { ScrollablePane, ScrollbarVisibility } from '@fluentui/react';
import SearchDropdown from 'components/SearchDropdown';
import { MessageBar, MessageBarType } from '@fluentui/react/lib/MessageBar';

function Form({
  isValid,
  values,
  errors,
  touched,
  loading,
  handleChange,
  handleBlur,
  handleFocus,
  handleSubmit,
  isSubmitting,
  buttonText,
  setFieldValue,
  setFieldTouched,
  errorMessage,
  setErrorMessage,
}) {
  return (
    <Stack>
      <ScrollablePane scrollbarVisibility={ScrollbarVisibility.auto}>
        <form action="" onSubmit={handleSubmit} className="form-custom">
          <Stack className="section-button">
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg12">
                  <PrimaryButton
                    className="primary-btn"
                    disabled={!isValid || isSubmitting || loading}
                    onClick={handleSubmit}
                    text={loading ? 'Loading' : buttonText}
                  />
                </div>
              </div>
            </div>
          </Stack>

          <Stack>
            {errorMessage && (
              <MessageBar
                messageBarType={MessageBarType.error}
                isMultiline={false}
                onDismiss={() => setErrorMessage(null)}
                dismissButtonAriaLabel="Close">
                {errorMessage}
              </MessageBar>
            )}
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg4">
                  <TextField
                    name="fullName"
                    label="Full Name"
                    placeholder="Enter full name here"
                    required={true}
                    disabled={isSubmitting || loading}
                    value={values.fullName || ''}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onFocus={handleFocus}
                    errorMessage={touched.fullName && errors.fullName}
                  />
                </div>
                <div className="ms-Grid-col ms-lg4">
                  <TextField
                    name="phoenNumber"
                    label="Phone"
                    placeholder="Enter phone number here"
                    required={true}
                    disabled={isSubmitting || loading}
                    value={values.phoenNumber || ''}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onFocus={handleFocus}
                    errorMessage={touched.phoenNumber && errors.phoenNumber}
                  />
                </div>
              </div>
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg4">
                  <TextField
                    name="email"
                    label="E-mail"
                    placeholder="Enter email here"
                    required={true}
                    disabled={isSubmitting || loading}
                    value={values.email || ''}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onFocus={handleFocus}
                    errorMessage={touched.email && errors.email}
                  />
                </div>
                <div className="ms-Grid-col ms-lg4">
                  <SearchDropdown
                    name="district"
                    label="District"
                    placeholder="choose a district"
                    value={values.district || ''}
                    required={true}
                    disabled={isSubmitting || loading}
                    getText={(item) => item.name}
                    getValue={(item) => item.id}
                    url="api/v1/MasterData/districts"
                    onBlur={() => setFieldTouched('district')}
                    errorMessage={touched.district && errors.district}
                    onChange={(id) => setFieldValue('district', id)}
                  />
                </div>
                <div className="ms-Grid-col ms-lg4">
                  <SearchDropdown
                    name="mohArea"
                    label="Moh Area"
                    placeholder="choose a mohArea"
                    value={values.mohArea || ''}
                    required={true}
                    getText={(item) => item.name}
                    getValue={(item) => item.id}
                    url={`/api/v1/MasterData/moh-areas/${values.district?.id}`}
                    disabled={!values.district || isSubmitting || loading}
                    onBlur={() => setFieldTouched('mohArea')}
                    errorMessage={touched.mohArea && errors.mohArea}
                    onChange={(id) => setFieldValue('mohArea', id)}
                  />
                </div>
              </div>
            </div>
          </Stack>
        </form>
      </ScrollablePane>
    </Stack>
  );
}
const phoneRegExp = /94\d{9}$/;

export default withFormik({
  validationSchema: object().shape({
    fullName: string().required('Full name field is required'),
    phoenNumber: string()
      .matches(phoneRegExp, 'Mobile number is not valid')
      .required('Phone number field is required'),
    email: string()
      .required('E-mail field is required')
      .email('Email field must be a valid email'),
    district: object().required('District is a required field.'),
    mohArea: object().required('Moh area is a required field.'),
  }),
  enableReinitialize: true,
  mapPropsToValues: ({ item }) => ({
    edit: !!item,
    fullName: item ? item.fullName : '',
    phoenNumber: item ? item.phoenNumber : '',
    email: item ? item.email : '',
    district: item
      ? {
          name: item.district ? item.district.name : '',
          id: item.district ? item.district.id : '',
        }
      : '',
    mohArea: item
      ? {
          name: item.district ? item.district.name : '',
          id: item.district ? item.district.id : '',
        }
      : '',
  }),
  handleSubmit: (values, { props, ...actions }) => {
    props.onSubmit(
      {
        ...values,
        districtId: values.district ? values.district.id : null,
        mohAreaId: values.mohArea ? values.mohArea.id : null,
      },
      actions,
    );
  },
})(Form);
