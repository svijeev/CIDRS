import React from 'react';
import { useSelector } from 'react-redux';
import padStart from 'lodash-es/padStart';
import { Stack } from '@fluentui/react/lib/Stack';
import { CommandButton } from '@fluentui/react/lib';
import Breadcrumb from 'components/Breadcrumb';
import ResourceTable from 'components/ResourceTable';
import * as routes from 'constants/routes';
import moment from 'moment';
import { getUser } from 'selectors/auth';

const breadcrumbItems = [
  {
    text: 'PHI',
    key: 'index',
    isCurrentItem: true,
  },
];

export const columns = [
  {
    key: 'identifier',
    name: 'Identifier',
    fieldName: 'identifier',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'number',
    isPadded: true,
  },
  {
    key: 'fullName',
    name: 'Full Name',
    fieldName: 'fullName',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
  },
  {
    key: 'phoneNumber',
    name: 'phone',
    fieldName: 'phoneNumber',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
  },
  {
    key: 'mohArea',
    name: 'MOH Area',
    fieldName: 'mohArea',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => padStart(item?.mohArea?.name),
  },
  {
    key: 'district',
    name: 'District',
    fieldName: 'district',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => padStart(item?.district?.name),
  },
  {
    key: 'user',
    name: 'Created AT',
    fieldName: 'user',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => moment(item?.createdAt).format('LL'),
  },
];

function Customer({ history, location }) {
  const user = useSelector(getUser);
  return (
    <Stack className="inner-page-panel">
      <Breadcrumb items={breadcrumbItems} />
      <Stack
        horizontal
        verticalAlign="center"
        tokens={{ padding: '5px 10px 5px 0' }}
        horizontalAlign="space-between">
        {user?.userType !== 2 && (
          <CommandButton
            iconProps={{ iconName: 'Add' }}
            text={`Create`}
            onClick={() => history.push(routes.PHI_CREATE)}
          />
        )}
      </Stack>
      <ResourceTable
        url="api/v1/Phi"
        columns={columns}
        viewRoute={(item) => routes.PHI_SHOW.replace(':id', item.id)}
        disableActions={{
          view: false,
          edit: true,
          delete: true,
        }}
      />
    </Stack>
  );
}

export default Customer;
