import React from 'react';
import { Chart } from 'react-google-charts';
import { startCase } from 'lodash-es';

function penalizationChart({ item }) {
  const data = [['Penalization', 'Count']].concat(
    Object.keys(item).map(function (key) {
      return [startCase(key), item[key].value.count];
    }),
  );
  return (
    <Chart
      height={'300px'}
      chartType="PieChart"
      loader={<div>Loading Chart</div>}
      data={data}
      options={{
        title: 'Penalization',
        pieHole: 0.4,
      }}
      rootProps={{ 'data-testid': '1' }}
    />
  );
}

export default penalizationChart;
