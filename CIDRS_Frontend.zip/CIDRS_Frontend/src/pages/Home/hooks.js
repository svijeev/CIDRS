import { useState, useEffect, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { loadSummary } from 'actions/home';

export function useLoadSummary() {
  const [items, setItems] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const dispatch = useDispatch();

  const onLoadSummary = useCallback(async () => {
    setLoading(true);

    try {
      const response = await dispatch(loadSummary());
      setItems(response);
    } catch (e) {}

    setLoading(false);
  }, [dispatch]);

  useEffect(() => {
    onLoadSummary();
  }, [onLoadSummary]);

  return {
    items,
    isLoading,
  };
}
