import React from 'react';
import { Chart } from 'react-google-charts';
import { startCase } from 'lodash-es';

function EnvironmentChart({ item }) {
  const data = [['Environment', 'Count']].concat(
    Object.keys(item).map(function (key) {
      return [startCase(key), item[key].value.count];
    }),
  );
  return (
    <Chart
      height={'300px'}
      chartType="PieChart"
      loader={<div>Loading Chart</div>}
      data={data}
      options={{
        title: 'Environment',
        pieHole: 0.4,
        slices: {
          1: { color: 'red' },
          0: { color: 'green' },
        },
      }}
      rootProps={{ 'data-testid': '1' }}
    />
  );
}

export default EnvironmentChart;
