import React from 'react';
import { Stack } from '@fluentui/react/lib/Stack';
import { Text } from '@fluentui/react/lib/Text';
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';
import { ScrollablePane, ScrollbarVisibility } from '@fluentui/react/lib';
import { Icon } from '@fluentui/react';
import Breadcrumb from 'components/Breadcrumb';
import { useLoadSummary } from './hooks';
import EnvironmentChart from './environmentChart';
import PenalizationChart from './penalizationChart';
import * as routes from 'constants/routes';

function Home({ history }) {
  const breadcrumbItems = [
    {
      text: 'Home',
      key: 'index',
      isCurrentItem: true,
    },
  ];
  const { items, isLoading } = useLoadSummary();
  console.log(items?.global);
  if (isLoading) {
    return (
      <Stack styles={{ root: { flex: 1, justifyContent: 'center' } }}>
        <Spinner label="Loading..." size={SpinnerSize.large} />
      </Stack>
    );
  }
  return (
    <Stack className="inner-page-panel">
      <Stack>
        <Breadcrumb items={breadcrumbItems} />
      </Stack>
      <Stack className="show-panel">
        <Stack styles={{ root: { position: 'relative', flex: 1 } }}>
          <ScrollablePane scrollbarVisibility={ScrollbarVisibility.auto}>
            {items?.global && (
              <Stack>
                <div className="ms-Grid" dir="ltr">
                  <div className="ms-Grid-row">
                    <div className="ms-Grid-col ms-lg12">
                      <Stack className="widget-block-heading">
                        <Text variant="medium">Global Summery</Text>
                      </Stack>
                      <Stack>
                        <div className="ms-Grid" dir="ltr">
                          <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-lg4">
                              <div className="info-box">
                                <span className="info-box-icon bg-purple">
                                  <Icon iconName="DietPlanNotebook" />
                                </span>
                                <div className="info-box-content">
                                  <span className="info-box-text">
                                    Home Surrounding Alerts
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.overview
                                      ? items?.global?.overview
                                          ?.homeSurroundingAlerts
                                      : 0}
                                  </span>
                                  <div className="info-box-content-divider" />
                                  <span className="info-box-text">
                                    Public Surrounding Complaints
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.overview
                                      ? items?.global?.overview
                                          ?.publicSurroundingComplaints
                                      : 0}
                                  </span>
                                  <div className="info-box-content-divider" />
                                  <span className="info-box-text">
                                    Registered Chief Occupants
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.overview
                                      ? items?.global?.overview
                                          ?.registeredChiefOccupants
                                      : 0}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-lg4">
                              <div className="info-box">
                                <span className="info-box-icon bg-aqua">
                                  <Icon iconName="Home" />
                                </span>
                                <div className="info-box-content">
                                  <span
                                    className="info-box-text"
                                    onClick={() => history.push(`${routes.APPLICATION}?type=1&timeFrequency=1&isRelative=false`)}>
                                    Home Surrounding - Day
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.homeSurroundings
                                      ? items?.global?.homeSurroundings?.today
                                      : 0}
                                  </span>
                                  <div className="info-box-content-divider" />
                                  <span className="info-box-text"   onClick={() => history.push(`${routes.APPLICATION}?type=1&timeFrequency=2&isRelative=false`)}>
                                    Home Surrounding - Week
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.homeSurroundings
                                      ? items?.global?.homeSurroundings?.week
                                      : 0}
                                  </span>
                                  <div className="info-box-content-divider" />
                                  <span className="info-box-text"   onClick={() => history.push(`${routes.APPLICATION}?type=1&timeFrequency=3&isRelative=false`)}>
                                    Home Surrounding - Month
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.homeSurroundings
                                      ? items?.global?.homeSurroundings?.month
                                      : 0}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="ms-Grid-col ms-lg4">
                              <div className="info-box">
                                <span className="info-box-icon bg-teal">
                                  <Icon iconName="PeopleRepeat" />
                                </span>
                                <div className="info-box-content">
                                  <span className="info-box-text"   onClick={() => history.push(`${routes.APPLICATION}?type=2&timeFrequency=1&isRelative=false`)}>
                                    Public Surrounding - Day
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.publicSurroundings
                                      ? items?.global?.publicSurroundings?.today
                                      : 0}
                                  </span>
                                  <div className="info-box-content-divider" />
                                  <span className="info-box-text"   onClick={() => history.push(`${routes.APPLICATION}?type=2&timeFrequency=2&isRelative=false`)}>
                                    Public Surrounding - Week
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.publicSurroundings
                                      ? items?.global?.publicSurroundings?.week
                                      : 0}
                                  </span>
                                  <div className="info-box-content-divider" />
                                  <span className="info-box-text"   onClick={() => history.push(`${routes.APPLICATION}?type=2&timeFrequency=3&isRelative=false`)}>
                                    Public Surrounding - Month
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.publicSurroundings
                                      ? items?.global?.publicSurroundings?.month
                                      : 0}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="ms-Grid-col ms-lg4">
                              <div className="info-box">
                                <span className="info-box-icon bg-purple">
                                  <Icon iconName="UserFollowed" />
                                </span>
                                <div className="info-box-content">
                                  <span className="info-box-text">
                                    Chief Occupant - Day
                                  </span>
                                  <span className="info-box-number"   onClick={() => history.push(`${routes.APPLICATION}?type=3&timeFrequency=1&isRelative=false`)}>
                                    {items?.global?.chiefOccupants
                                      ? items?.global?.chiefOccupants?.today
                                      : 0}
                                  </span>
                                  <div className="info-box-content-divider" />
                                  <span className="info-box-text"   onClick={() => history.push(`${routes.APPLICATION}?type=3&timeFrequency=2&isRelative=false`)}>
                                    Chief Occupant - Week
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.chiefOccupants
                                      ? items?.global?.chiefOccupants?.week
                                      : 0}
                                  </span>
                                  <div className="info-box-content-divider" />
                                  <span className="info-box-text"   onClick={() => history.push(`${routes.APPLICATION}?type=3&timeFrequency=3&isRelative=false`)}>
                                    Chief Occupant - Month
                                  </span>
                                  <span className="info-box-number">
                                    {items?.global?.chiefOccupants
                                      ? items?.global?.chiefOccupants?.month
                                      : 0}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Stack>
                    </div>
                  </div>
                </div>
              </Stack>
            )}
            <Stack>
              <div className="ms-Grid" dir="ltr">
                <div className="ms-Grid-row">
                  <div className="ms-Grid-col ms-lg6">
                    <Stack className="widget-block-heading">
                      <Text variant="medium">Environment Details</Text>
                    </Stack>
                    {items?.global?.environment && (
                      <EnvironmentChart item={items?.global?.environment} />
                    )}
                  </div>
                  <div className="ms-Grid-col ms-lg6">
                    <Stack className="widget-block-heading">
                      <Text variant="medium">Penalization Details</Text>
                    </Stack>
                    {items?.global?.penalization && (
                      <PenalizationChart item={items?.global?.penalization} />
                    )}
                  </div>
                </div>
              </div>
            </Stack>

            {items?.related && (
              <>
                <Stack>
                  <div className="ms-Grid" dir="ltr">
                    <div className="ms-Grid-row">
                      <div className="ms-Grid-col ms-lg12">
                        <Stack className="widget-block-heading">
                          <Text variant="medium">Related Summery </Text>
                        </Stack>
                        <Stack>
                          <div className="ms-Grid" dir="ltr">
                            <div className="ms-Grid-row">
                              <div className="ms-Grid-col ms-lg4">
                                <div className="info-box">
                                  <span className="info-box-icon bg-purple">
                                    <Icon iconName="DietPlanNotebook" />
                                  </span>
                                  <div className="info-box-content">
                                    <span className="info-box-text">
                                      Home Surrounding Alerts
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.overview
                                        ? items?.related?.overview
                                            ?.homeSurroundingAlerts
                                        : 0}
                                    </span>
                                    <div className="info-box-content-divider" />
                                    <span className="info-box-text">
                                      Public Surrounding Complaints
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.overview
                                        ? items?.related?.overview
                                            ?.publicSurroundingComplaints
                                        : 0}
                                    </span>
                                    <div className="info-box-content-divider" />
                                    <span className="info-box-text">
                                      Registered Chief Occupants
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.overview
                                        ? items?.related?.overview
                                            ?.registeredChiefOccupants
                                        : 0}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="ms-Grid-row">
                              <div className="ms-Grid-col ms-lg4">
                                <div className="info-box">
                                  <span className="info-box-icon bg-aqua">
                                    <Icon iconName="Home" />
                                  </span>
                                  <div className="info-box-content">
                                    <span className="info-box-text"   onClick={() => history.push(`${routes.APPLICATION}?type=1&timeFrequency=1&isRelative=true`)}>
                                      Home Surrounding - Day
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.homeSurroundings
                                        ? items?.related?.homeSurroundings
                                            ?.today
                                        : 0}
                                    </span>
                                    <div className="info-box-content-divider" />
                                    <span className="info-box-text" onClick={() => history.push(`${routes.APPLICATION}?type=1&timeFrequency=2&isRelative=true`)}>
                                      Home Surrounding - Week
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.homeSurroundings
                                        ? items?.related?.homeSurroundings?.week
                                        : 0}
                                    </span>
                                    <div className="info-box-content-divider" />
                                    <span className="info-box-text" onClick={() => history.push(`${routes.APPLICATION}?type=1&timeFrequency=3&isRelative=true`)}>
                                      Home Surrounding - Month
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.homeSurroundings
                                        ? items?.related?.homeSurroundings
                                            ?.month
                                        : 0}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className="ms-Grid-col ms-lg4">
                                <div className="info-box">
                                  <span className="info-box-icon bg-teal">
                                    <Icon iconName="PeopleRepeat" />
                                  </span>
                                  <div className="info-box-content">
                                    <span className="info-box-text" onClick={() => history.push(`${routes.APPLICATION}?type=2&timeFrequency=1&isRelative=true`)}>
                                      Public Surrounding - Day
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.publicSurroundings
                                        ? items?.related?.publicSurroundings
                                            ?.today
                                        : 0}
                                    </span>
                                    <div className="info-box-content-divider" />
                                    <span className="info-box-text" onClick={() => history.push(`${routes.APPLICATION}?type=2&timeFrequency=2&isRelative=true`)}>
                                      Public Surrounding - Week
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.publicSurroundings
                                        ? items?.related?.publicSurroundings
                                            ?.week
                                        : 0}
                                    </span>
                                    <div className="info-box-content-divider" />
                                    <span className="info-box-text" onClick={() => history.push(`${routes.APPLICATION}?type=2&timeFrequency=2&isRelative=true`)}>
                                      Public Surrounding - Month
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.publicSurroundings
                                        ? items?.related?.publicSurroundings
                                            ?.month
                                        : 0}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className="ms-Grid-col ms-lg4">
                                <div className="info-box">
                                  <span className="info-box-icon bg-purple">
                                    <Icon iconName="UserFollowed" />
                                  </span>
                                  <div className="info-box-content">
                                    <span className="info-box-text" onClick={() => history.push(`${routes.APPLICATION}?type=3&timeFrequency=1&isRelative=true`)}>
                                      Chief Occupant - Day
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.chiefOccupants
                                        ? items?.related?.chiefOccupants?.today
                                        : 0}
                                    </span>
                                    <div className="info-box-content-divider" />
                                    <span className="info-box-text" onClick={() => history.push(`${routes.APPLICATION}?type=3&timeFrequency=2&isRelative=true`)}>
                                      Chief Occupant - Week
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.chiefOccupants
                                        ? items?.related?.chiefOccupants?.week
                                        : 0}
                                    </span>
                                    <div className="info-box-content-divider" />
                                    <span className="info-box-text" onClick={() => history.push(`${routes.APPLICATION}?type=3&timeFrequency=3&isRelative=true`)}>
                                      Chief Occupant - Month
                                    </span>
                                    <span className="info-box-number">
                                      {items?.related?.chiefOccupants
                                        ? items?.related?.chiefOccupants?.month
                                        : 0}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </Stack>
                      </div>
                    </div>
                  </div>
                </Stack>
                <Stack>
                  <div className="ms-Grid" dir="ltr">
                    <div className="ms-Grid-row">
                      <div className="ms-Grid-col ms-lg6">
                        <Stack className="widget-block-heading">
                          <Text variant="medium">Environment Details</Text>
                        </Stack>
                        {items?.related?.environment && (
                          <EnvironmentChart
                            item={items?.related?.environment}
                          />
                        )}
                      </div>
                      <div className="ms-Grid-col ms-lg6">
                        <Stack className="widget-block-heading">
                          <Text variant="medium">Penalization Details</Text>
                        </Stack>
                        {items?.related?.penalization && (
                          <PenalizationChart
                            item={items?.related?.penalization}
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </Stack>
              </>
            )}
          </ScrollablePane>
        </Stack>
      </Stack>
    </Stack>
  );
}

export default Home;
