import React from 'react';
import { Stack } from '@fluentui/react/lib/Stack';
import Breadcrumb from 'components/Breadcrumb';
import ResourceTable from 'components/ResourceTable';
import * as routes from 'constants/routes';
import { urlSearch } from 'lib/helpers';

export const columns = [
  {
    key: 'id',
    name: 'ID',
    fieldName: 'id',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    minWidth: 50,
    maxWidth: 50,
    data: 'number',
    isPadded: true,
  },
  {
    key: 'identifier',
    name: 'Identifier',
    fieldName: 'identifier',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    minWidth: 100,
    maxWidth: 100,
    data: 'number',
    isPadded: true,
  },
];

function Application({ history, location, match }) {
  const breadcrumbItems = [
    {
      text: 'Home',
      key: 'index',
      onClick: () => history.push(routes.HOME),
    },
    {
      text: 'Application',
      key: 'index',
      isCurrentItem: true,
    },
  ];
  const { type, timeFrequency, isRelative } = urlSearch(location.search);
  return (
    <Stack className="inner-page-panel">
      <Breadcrumb items={breadcrumbItems} />
      <Stack
        horizontal
        verticalAlign="center"
        tokens={{ padding: '5px 10px 5px 0' }}
        horizontalAlign="space-between"></Stack>
      <ResourceTable
        url={`api/v1/Statistics/application-details?type=${parseInt(type)}&timeFrequency=${parseInt(timeFrequency)}&isRelative=${isRelative}`}
        columns={columns}
        disableAction
      />
    </Stack>
  );
}

export default Application;
