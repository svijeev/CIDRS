import React from 'react';
import { withFormik } from 'formik';
import { object, string } from 'yup';
import { Stack } from '@fluentui/react/lib/Stack';
import { Text } from '@fluentui/react/lib/Text';
import { TextField } from '@fluentui/react/lib/TextField';
import { PrimaryButton, ActionButton } from '@fluentui/react/lib/Button';
import { ReactComponent as Logo } from 'assets/svg/logo.svg';

function Form({
  succeeded,
  isValid,
  history,
  values,
  errors,
  touched,
  handleChange,
  handleBlur,
  handleFocus,
  handleSubmit,
  isSubmitting,
}) {
  return (
    <form action="" onSubmit={handleSubmit}>
      <Stack horizontalAlign="center" verticalAlign="center">
        <Stack styles={{ root: { width: '400px', height: '100%' } }}>
          <Stack horizontalAlign="center">
            <Logo className="logo-image" />
            <Text variant={'large'} styles={{ root: { marginBottom: '10px' } }}>
              {succeeded
                ? `Reset link has been sent to ${values.username}`
                : 'Find Your Account'}
            </Text>
            {succeeded ? null : (
              <Text variant={'small'}>
                Enter your email address or mobile number to search for your
                account.
              </Text>
            )}
          </Stack>
          {succeeded ? null : (
            <>
              <TextField
                name="username"
                label="Email Address"
                value={values.username}
                disabled={isSubmitting}
                placeholder="Please enter your email address here"
                onChange={handleChange}
                onBlur={handleBlur}
                onFocus={handleFocus}
                errorMessage={touched.username && errors.username}
              />
              <Stack horizontalAlign="end" style={{ marginTop: '-10px' }}>
                <ActionButton onClick={() => history.goBack()}>
                  <Text style={{ color: '#0078D4' }}> Back</Text>
                </ActionButton>
              </Stack>
              <PrimaryButton
                className="login-btn"
                text={isSubmitting ? 'Logging...' : 'SUBMIT'}
                disabled={!isValid}
                onClick={handleSubmit}
                styles={{ root: { marginBottom: '10px' } }}
              />
            </>
          )}
          {succeeded && (
            <PrimaryButton
              className="login-btn"
              text="Back"
              styles={{ root: { marginBottom: '10px' } }}
              onClick={() => history.goBack()}
            />
          )}
        </Stack>
      </Stack>
    </form>
  );
}

export default withFormik({
  validationSchema: object().shape({
    username: string()
      .email('Email field must be a valid email')
      .required('Email address is a required field'),
  }),
  handleSubmit: (values, { props, ...actions }) => {
    props.onSubmit(values, actions);
  },
})(Form);
