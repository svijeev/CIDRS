import { useCallback, useState } from 'react';
import { useDispatch } from 'react-redux';
import { forgetPassword } from 'actions/auth';

export function useForgetPassword() {
  const dispatch = useDispatch();
  const [errorMessage, setErrorMessage] = useState(null);
  const [succeeded, setSucceeded] = useState(null);

  const onSubmit = useCallback(
    async (values, actions) => {
      actions.setSubmitting(true);

      let res = await dispatch(forgetPassword(values));
      if (res.succeeded) {
        setSucceeded(res.succeeded);
      }
      if (res.errors) {
        actions.setErrors(res.errors);
        setErrorMessage(res.errors);
      }
    },
    [dispatch],
  );
  return { onSubmit, errorMessage, setErrorMessage, succeeded };
}
