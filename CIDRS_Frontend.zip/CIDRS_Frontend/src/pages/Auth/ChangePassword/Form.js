import React from 'react';
import { withFormik } from 'formik';
import { object, string } from 'yup';
import { Stack } from '@fluentui/react/lib/Stack';
import { Text } from '@fluentui/react/lib/Text';
import { TextField } from '@fluentui/react/lib/TextField';
import { PrimaryButton, DefaultButton } from '@fluentui/react/lib/Button';
import { ScrollablePane, ScrollbarVisibility } from '@fluentui/react';
import { MessageBar, MessageBarType } from '@fluentui/react/lib/MessageBar';
function Form({
  isValid,
  values,
  errors,
  touched,
  loading,
  handleChange,
  handleBlur,
  handleFocus,
  handleSubmit,
  history,
  isSubmitting,
  errorMessage,
  setErrorMessage,
}) {
  return (
    <Stack>
      <ScrollablePane scrollbarVisibility={ScrollbarVisibility.auto}>
        <form action="" onSubmit={handleSubmit} className="form-custom">
          <div className="m-l-10">
            <Text>Strong password required</Text> <br />
            <Text>Enter 8-256 characters.</Text> <br />
            <Text>Do not include common words or names.</Text>
            <br />
            <Text>
              Combine uppercase letters, lowercase letters, numbers, and
              symbols.
            </Text>
          </div>
          <br />
          <Stack>
            {errorMessage && (
              <MessageBar
                messageBarType={MessageBarType.error}
                isMultiline={false}
                onDismiss={() => setErrorMessage(null)}
                dismissButtonAriaLabel="Close">
                {errorMessage}
              </MessageBar>
            )}
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg4">
                  <TextField
                    name="email"
                    label="E-mail"
                    placeholder="enter email here"
                    required={true}
                    disabled={true}
                    value={values.email || ''}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onFocus={handleFocus}
                    errorMessage={touched.email && errors.email}
                  />
                </div>
              </div>
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg4">
                  <TextField
                    name="currentPassword"
                    label="Current Password"
                    placeholder="enter current password here"
                    type="password"
                    required={true}
                    disabled={loading || isSubmitting}
                    value={values.currentPassword || ''}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onFocus={handleFocus}
                    errorMessage={
                      touched.currentPassword && errors.currentPassword
                    }
                    canRevealPassword
                    revealPasswordAriaLabel="Show password"
                  />
                </div>
              </div>
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg4">
                  <TextField
                    name="newPassword"
                    label="New Passwor"
                    placeholder="enter new password  here"
                    type="password"
                    required={true}
                    disabled={loading || isSubmitting}
                    value={values.newPassword || ''}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onFocus={handleFocus}
                    errorMessage={touched.newPassword && errors.newPassword}
                    canRevealPassword
                    revealPasswordAriaLabel="Show password"
                  />
                </div>
              </div>
            </div>
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg12">
                  <PrimaryButton
                    className="primary-btn"
                    disabled={!isValid || isSubmitting || loading}
                    onClick={handleSubmit}
                    text={loading ? 'Loading' : 'Submit'}
                  />
                  <DefaultButton
                    className="primary-btn m-l-10"
                    onClick={() => history.goBack()}
                    disabled={isSubmitting || loading}
                    text="Cancel"></DefaultButton>
                </div>
              </div>
            </div>
          </Stack>
        </form>
      </ScrollablePane>
    </Stack>
  );
}

export default withFormik({
  validationSchema: object().shape({
    email: string()
      .required('E-mail field is required')
      .email('Email field must be a valid email'),
    currentPassword: string().required('Current password field is required'),
    newPassword: string().required('New password field is required'),
  }),
  enableReinitialize: true,
  mapPropsToValues: ({ item }) => ({
    email: item ? item.email : '',
  }),
  handleSubmit: (values, { props, ...actions }) => {
    props.onSubmit(values, actions);
  },
})(Form);
