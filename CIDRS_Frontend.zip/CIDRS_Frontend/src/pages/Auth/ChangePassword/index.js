import React, { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Stack } from '@fluentui/react/lib/Stack';
import Breadcrumb from 'components/Breadcrumb';
import { CHANGE_PASSWORD_SUCCESS } from 'constants/messages';
import { changePassword } from 'actions/changePassword';
import * as routes from 'constants/routes';
import Form from './Form';
import { getUser } from 'selectors/auth';
import toast from 'lib/toast';
import { MessageBar, MessageBarType } from '@fluentui/react/lib/MessageBar';


function Create({ history }) {
  const [errorMessage, setErrorMessage] = React.useState(null);
  const dispatch = useDispatch();
  const user = useSelector(getUser);

  const breadcrumbItems = [
    {
      text: 'Home',
      key: 'home',
      onClick: () => history.push(routes.HOME),
    },
    {
      text: 'Change Password',
      key: 'change-password',
      isCurrentItem: true,
    },
  ];

  const onStore = useCallback(
    async (values, actions) => {
      actions.setSubmitting(true);

      const response = await dispatch(changePassword(values));
      if (response.succeeded) {
        history.push(routes.HOME);
        toast.success(CHANGE_PASSWORD_SUCCESS);
      }
      if (response.errors) {
        actions.setErrors(response.errors);
        setErrorMessage(response.errors);
        actions.setSubmitting(false);
      }
    },
    [dispatch, history],
  );

  return (
    <Stack className="inner-page-panel">
      <Stack>
        <Breadcrumb items={breadcrumbItems} />
      </Stack>
      <Stack>
        {user.hasTempPassword === true ? 
        <MessageBar
                messageBarType={MessageBarType.warning}
                isMultiline={false}
                dismissButtonAriaLabel="Close">
                "Your password is temporary, We strongly recommend to change it right now."
              </MessageBar> : null }
        </Stack>
      <Stack className="form-panel">        
        <Form
          onSubmit={onStore}
          item={user}
          history={history}
          errorMessage={errorMessage}
          setErrorMessage={setErrorMessage}
        />
      </Stack>
    </Stack>
  );
}

export default Create;
