import React from 'react';
import padStart from 'lodash-es/padStart';
import { Stack } from '@fluentui/react/lib/Stack';
import { CommandButton } from '@fluentui/react/lib';
import Breadcrumb from 'components/Breadcrumb';
import ResourceTable from 'components/ResourceTable';
import * as routes from 'constants/routes';

const breadcrumbItems = [
  {
    text: 'Police',
    key: 'index',
    isCurrentItem: true,
  },
];

export const columns = [
  {
    key: 'identifier',
    name: 'Identifier',
    fieldName: 'identifier',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'number',
    isPadded: true,
  },
  {
    key: 'fullName',
    name: 'Full Name',
    fieldName: 'fullName',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
  },
  {
    key: 'phoneNumber',
    name: 'phone',
    fieldName: 'mobile',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
  },
  {
    key: 'station',
    name: 'Station',
    fieldName: 'policeStation',
    isRowHeader: true,
    isResizable: true,
    isSorted: false,
    data: 'string',
    isPadded: true,
    onRender: (item) => padStart(item?.policeStation?.name),
  },
];

function Customer({ history, location }) {
  return (
    <Stack className="inner-page-panel">
      <Breadcrumb items={breadcrumbItems} />
      <Stack
        horizontal
        verticalAlign="center"
        tokens={{ padding: '5px 10px 5px 0' }}
        horizontalAlign="space-between">
        <CommandButton
          iconProps={{ iconName: 'Add' }}
          text={`Create`}
          onClick={() => history.push(routes.POLICE_CREATE)}
        />
      </Stack>
      <ResourceTable
        url="api/v1/Police"
        columns={columns}
        viewRoute={(item) => routes.POLICE_SHOW.replace(':id', item.id)}
        disableActions={{
          view: false,
          edit: true,
          delete: true,
        }}
      />
    </Stack>
  );
}

export default Customer;
