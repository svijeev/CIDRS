import React, { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { Stack } from '@fluentui/react/lib/Stack';
import Breadcrumb from 'components/Breadcrumb';
import { storeItem } from 'actions/police';
import * as routes from 'constants/routes';
import Form from '../Form';
import toast from 'lib/toast';
import { POLICE_CREATE_SUCCESS } from 'constants/messages';

function Create({ history }) {
  const [errorMessage, setErrorMessage] = React.useState(null);

  const dispatch = useDispatch();
  const breadcrumbItems = [
    {
      text: 'Police',
      key: 'index',
      onClick: () => history.push(routes.POLICE),
    },
    {
      text: 'Create',
      key: 'create',
      isCurrentItem: true,
    },
  ];

  const onStore = useCallback(
    async (values, actions) => {
      actions.setSubmitting(true);

      const response = await dispatch(storeItem(values));
      if (response.succeeded) {
        toast.success(POLICE_CREATE_SUCCESS);
        history.push(routes.POLICE);
      }
      if (response.errors) {
        actions.setErrors(response.errors);
        setErrorMessage(response.errors);

        actions.setSubmitting(false);
      }
    },
    [dispatch, history],
  );

  return (
    <Stack className="inner-page-panel">
      <Stack>
        <Breadcrumb items={breadcrumbItems} />
      </Stack>
      <Stack className="form-panel">
        <Form
          onSubmit={onStore}
          buttonText="Submit"
          errorMessage={errorMessage}
          setErrorMessage={setErrorMessage}
        />
      </Stack>
    </Stack>
  );
}

export default Create;
