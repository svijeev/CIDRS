import React from 'react';
import { withFormik } from 'formik';
import { object, string } from 'yup';
import { Stack } from '@fluentui/react/lib/Stack';
import { TextField } from '@fluentui/react/lib/TextField';
import { PrimaryButton } from '@fluentui/react/lib/Button';
import { ScrollablePane, ScrollbarVisibility } from '@fluentui/react';
import SearchDropdown from 'components/SearchDropdown';
import { MessageBar, MessageBarType } from '@fluentui/react/lib/MessageBar';

function Form({
  isValid,
  values,
  errors,
  touched,
  loading,
  handleChange,
  handleBlur,
  handleFocus,
  handleSubmit,
  isSubmitting,
  buttonText,
  setFieldValue,
  setFieldTouched,
  errorMessage,
  setErrorMessage,
}) {
  return (
    <Stack>
      <ScrollablePane scrollbarVisibility={ScrollbarVisibility.auto}>
        <form action="" onSubmit={handleSubmit} className="form-custom">
          <Stack className="section-button">
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg12">
                  <PrimaryButton
                    className="primary-btn"
                    disabled={!isValid || isSubmitting || loading}
                    onClick={handleSubmit}
                    text={loading ? 'Loading' : buttonText}
                  />
                </div>
              </div>
            </div>
          </Stack>

          <Stack>
            {errorMessage && (
              <MessageBar
                messageBarType={MessageBarType.error}
                isMultiline={false}
                onDismiss={() => setErrorMessage(null)}
                dismissButtonAriaLabel="Close">
                {errorMessage}
              </MessageBar>
            )}
            <div className="ms-Grid" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg4">
                  <TextField
                    name="fullName"
                    label="Full Name"
                    placeholder="Enter full name here"
                    required={true}
                    disabled={isSubmitting || loading}
                    value={values.fullName || ''}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onFocus={handleFocus}
                    errorMessage={touched.fullName && errors.fullName}
                  />
                </div>
              </div>
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-lg4">
                  <TextField
                    name="mobile"
                    label="Phone"
                    placeholder="Enter phone number here"
                    required={true}
                    disabled={isSubmitting || loading}
                    value={values.mobile || ''}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onFocus={handleFocus}
                    errorMessage={touched.mobile && errors.mobile}
                  />
                </div>
                <div className="ms-Grid-col ms-lg4">
                  <SearchDropdown
                    name="station"
                    label="Station"
                    placeholder="choose a station"
                    value={values.station || ''}
                    required={true}
                    disabled={isSubmitting || loading}
                    getText={(item) => item.name}
                    getValue={(item) => item.id}
                    url="police-stations"
                    onBlur={() => setFieldTouched('station')}
                    errorMessage={touched.station && errors.station}
                    onChange={(id) => setFieldValue('station', id)}
                  />
                </div>
              </div>
            </div>
          </Stack>
        </form>
      </ScrollablePane>
    </Stack>
  );
}
const phoneRegExp = /94\d{9}$/;

export default withFormik({
  validationSchema: object().shape({
    fullName: string().required('Full name field is required'),
    mobile: string()
      .matches(phoneRegExp, 'Mobile number is not valid')
      .required('Phone number field is required'),

    station: object().required('Station is a required field.'),
  }),
  enableReinitialize: true,
  mapPropsToValues: ({ item }) => ({
    edit: !!item,
    fullName: item ? item.fullName : '',
    mobile: item ? item.phoenNumber : '',
    station: item
      ? {
          name: item.station ? item.station.name : '',
          id: item.station ? item.station.id : '',
        }
      : '',
  }),
  handleSubmit: (values, { props, ...actions }) => {
    props.onSubmit(
      {
        ...values,
        policeStationId: values.station ? values.station.id : null,
      },
      actions,
    );
  },
})(Form);
