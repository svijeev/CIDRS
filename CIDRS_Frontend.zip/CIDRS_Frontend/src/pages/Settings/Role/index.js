import React from 'react';
import { Stack } from '@fluentui/react/lib/Stack';
import { Text } from '@fluentui/react/lib/Text';
import * as styles from './styles';
import Breadcrumb from 'components/Breadcrumb';

function index() {
  const breadcrumb = [
    {
      text: 'Users',
      key: 'index',
      isCurrentItem: true,
    },
  ];

  return (
    <Stack styles={styles.mainContainer}>
      <Stack>
        <Breadcrumb items={breadcrumb} />
      </Stack>
      <Stack>
        <Text>Role</Text>
      </Stack>
    </Stack>
  );
}

export default index;
