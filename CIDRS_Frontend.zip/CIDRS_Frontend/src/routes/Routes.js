import React, { lazy } from 'react';
import { Switch } from 'react-router-dom';
import Loader from './Loader';
import * as routes from 'constants/routes';
import AuthRoute from './AuthRoute';
import PrivateRoute from './PrivateRoute';

function Routes() {
  return (
    <Switch>
      <AuthRoute
        exact
        fallback={Loader}
        path={routes.LOGIN}
        component={lazy(() => import('pages/Auth/Login'))}
      />
      <AuthRoute
        exact
        fallback={Loader}
        path={routes.FORGET_PASSWORD}
        component={lazy(() => import('pages/Auth/ForgetPassword'))}
      />
      <PrivateRoute
        exact
        fallback={Loader}
        path={routes.CHANGE_PASSWORD}
        component={lazy(() => import('pages/Auth/ChangePassword'))}
      />
      <PrivateRoute
        exact
        fallback={Loader}
        path={routes.HOME}
        component={lazy(() => import('pages/Home'))}
      />
      <PrivateRoute
        exact
        model="Phi"
        method="index"
        path={routes.PHI}
        component={lazy(() => import('pages/Phi'))}
      />
      <PrivateRoute
        exact
        model="Phi"
        method="create"
        path={routes.PHI_CREATE}
        component={lazy(() => import('pages/Phi/Create'))}
      />
      <PrivateRoute
        exact
        model="Phi"
        method="view"
        path={routes.PHI_SHOW}
        component={lazy(() => import('pages/Phi/View'))}
      />

      <PrivateRoute
        exact
        model="District"
        method="index"
        path={routes.DISTRICTS}
        component={lazy(() => import('pages/MasterData/Districts'))}
      />
      <PrivateRoute
        exact
        model="Moh Areas"
        method="index"
        path={routes.MOH_AREA}
        component={lazy(() => import('pages/MasterData/MOHAreas'))}
      />
      <PrivateRoute
        exact
        model="Police Station"
        method="index"
        path={routes.POLICE_STATION}
        component={lazy(() => import('pages/MasterData/policeStation'))}
      />

      <PrivateRoute
        exact
        model="Chief Occupant"
        method="index"
        path={routes.CHIEF_OCCUPANT}
        component={lazy(() => import('pages/ChiefOccupant'))}
      />
      <PrivateRoute
        exact
        model="Chief Occupant"
        method="view"
        path={routes.CHIEF_OCCUPANT_SHOW}
        component={lazy(() => import('pages/ChiefOccupant/View'))}
      />

      <PrivateRoute
        exact
        model="Police"
        method="index"
        path={routes.POLICE}
        component={lazy(() => import('pages/Police'))}
      />
      <PrivateRoute
        exact
        model="Police"
        method="create"
        path={routes.POLICE_CREATE}
        component={lazy(() => import('pages/Police/Create'))}
      />
      <PrivateRoute
        exact
        model="Police"
        method="view"
        path={routes.POLICE_SHOW}
        component={lazy(() => import('pages/Police/View'))}
      />

      <PrivateRoute
        exact
        model="Work Items"
        method="index"
        path={routes.WORK_ITEMS}
        component={lazy(() => import('pages/WorkItems'))}
      />
      <PrivateRoute
        exact
        model="Work Items"
        method="view"
        path={routes.WORK_ITEMS_SHOW}
        component={lazy(() => import('pages/WorkItems/View'))}
      />
      <PrivateRoute
        exact
        model="application"
        method="index"
        path={routes.APPLICATION}
        component={lazy(() => import('pages/Statistics/application'))}
      />
    </Switch>
  );
}

export default Routes;
