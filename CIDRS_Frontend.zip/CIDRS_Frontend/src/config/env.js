module.exports = {
  timeout: 30000,
  name: 'CIDRS',
  detail: 'Community Interactive Dengue Reporting System',

  // URLs
  baseUrl: process.env.REACT_APP_API_URL,
  authUrl: process.env.REACT_APP_AUTH_URL,
  googleMapKey: process.env.REACT_APP_GOOGLE_MAP_KEY,

  // formats of date and time
  timeFormat: 'HH:mm:ss',
  dateFormat: 'YYYY-MM-DD',
  dateTimeFormat: 'YYYY-MM-DD HH:mm:ss',
};
