export const HOME = '/';
export const LOGIN = '/login';
export const CHANGE_PASSWORD = '/change-password';
export const FORGET_PASSWORD = '/forget-password';

// User
export const USER = '/users/';

// Roles Brands
export const ROLE = '/roles/';

export const PHI = '/phis/';
export const PHI_CREATE = '/phis/create';
export const PHI_SHOW = '/phis/:id';

export const CHIEF_OCCUPANT = '/chief-occupants/';
export const CHIEF_OCCUPANT_SHOW = '/chief-occupants/:id';

export const POLICE = '/polices/';
export const POLICE_CREATE = '/polices/create';
export const POLICE_SHOW = '/polices/:id';

export const WORK_ITEMS = '/work-items/';
export const WORK_ITEMS_SHOW = '/work-items/:id';
// Master Data
export const DISTRICTS = '/districts/';
export const MOH_AREA = '/moh-areas/';
export const POLICE_STATION = '/police-stations/';

export const APPLICATION = '/applications';
