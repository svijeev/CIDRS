export const CHANGE_PASSWORD_SUCCESS = 'Password changed successfully..!';
export const PHI_CREATE_SUCCESS = 'Phi create succeed!';
export const POLICE_CREATE_SUCCESS = 'Police create succeed!';
