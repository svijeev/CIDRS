import camelKeys from 'camelcase-keys';
import * as actionTypes from 'actions/auth/actionTypes';

const initialState = {
  token: null,
  refreshToken: null,
  tokenType: 'Bearer',
  user: {
    id: null,
    fullName: null,
    userName: null,
    email: null,
    emailConfirmed: null,
    phoneNumber: null,
    phoneNumberConfirmed: null,
    avatar: null,
    createdAt: null,
    userType: null,
    isActive: null,
  },
  permission: {},
};

const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.LOGIN_SUCCESS:
      return {
        ...state,
        ...camelKeys(action.response),
      };
    default:
      return state;
  }
};

export default authReducer;
